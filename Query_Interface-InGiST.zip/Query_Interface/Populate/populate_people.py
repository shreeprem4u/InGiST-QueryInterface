import psycopg2
import pika
import datetime
import time


def dbInsert1(mac, ex, ey, time):
	try:
		conn = psycopg2.connect("dbname='smartbuilding' port='5432' user='amudalab3' host='172.17.137.160' password='amudalab'")
		#conn = psycopg2.connect("dbname='smartbuilding' port='5432' user='system' host='172.17.9.60' password='system'")
		#the connection string
		cur = conn.cursor()		
		cur.execute("INSERT INTO main_person (mac,x,y,time,geom) VALUES (%s,%s,%s,%s,ST_SetSRID(ST_MakePoint(%s,%s),4326))",(mac,ex,ey,datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),ex,ey))
		#the query to insert into main_person table
		print("inserted row into main_person table at ",datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
		conn.commit()
		cur.close()
	except:
		print("Connection Failed")

#testing function need not to be called to generate synthetic data
def dbInsert2(mac, ex, ey, time):
	try:
		conn = psycopg2.connect("dbname='smartbuilding' port='5432' user='amudalab3' host='172.17.137.160' password='amudalab'")
		#conn = psycopg2.connect("dbname='smartbuilding' port='5432' user='system' host='172.17.9.60' password='system'")
		cur = conn.cursor()		
		cur.execute("INSERT INTO testdb (mac,x,y,time) VALUES (%s,%s,%s,%s)",(mac,ex,ey,datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
		#print("inserted row into testdb table at ",datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
		conn.commit()
		cur.close()
	except:
		print("Connection Failed")


#c1 to c25 MAC id's of the wifi device
# d1 to d25 corresponding x- coordinate values of c1 to c25 
# e1 to e25 corresponding y- coordinate values of c1 to c25 
i=0
c1 = 'CD-B6-11-G5-H2-61'
c2 = '4C-EB-42-55-2E-C3'
c3 = 'CD-B6-11-45-T2-64'
c4 = '4C-EB-42-D5-2E-C5'
c5 = 'CD-B6-11-G5-H2-66'
c6 = '88:79:7E:40:48:92'
c7 = '80:58:F8:A2:9E:F8'
c8 = '80:58:F8:A2:A7:9E'
c9 = '80:58:F8:A2:A3:60'
c10 ='80:58:F8:A2:A5:4C'
c11 = 'CD-B6-11-G5-H2-64'
c12 = '4C-EB-42-55-2E-C7'
c13 = 'CD-B6-11-45-T2-65'
c14 = '4C-EB-42-D5-2E-C6'
c15 = 'CD-B6-11-G5-H2-6K'
c16 = 'CD-B6-11-G5-H2-65'
c17 = '4C-EB-42-55-2E-C8'
c18 = 'CD-B6-11-45-T2-66'
c19 = '4C-EB-42-D5-2E-C7'
c20 = 'CD-B6-11-G5-H2-6L'
c21 = 'CD-B6-11-G5-H2-63'
c22 = '4C-EB-42-55-2E-C2'
c23 = 'CD-B6-11-45-T2-61'
c24 = '4C-EB-42-D5-2E-C9'
c25 = 'CD-B6-11-G5-H2-62'





d1 = 220409
d2 = 215409
d3 = 217409
d4 = 236928 
d5 = 236928 
d6 = 236032 
d7 = 209824
d8 = 209664 
d9 = 209216 
d10 = 208256 
d11 = 195584 
d12 = 195712 
d13 = 195328 
d14 = 195072 
d15 = 194624 
d16 = 195584 
d17 = 195840 
d18 = 195072 
d19 = 195584 
d20 = 196352 
d21 = 196096 
d22 = 224256
d23 = 224512 
d24 = 224512 
d25 = 240409


 




e1 = 766430
e2 = 746430
e3 = 756430
e4 = 783104
e5 = 778752
e6 = 758272
e7 = 763008
e8 = 777472
e9 = 772064
e10 = 770176
e11 = 782464
e12 = 771328
e13 = 759296
e14 = 710400
e15 = 697536
e16 = 696576
e17 = 695040
e18 = 693504
e19 = 688128
e20 = 681472
e21 = 672256
e22 = 710400
e23 = 698368
e24 = 683264
e25 = 763008



while i < 100:
	j = 0
	while j <100 :
		d1 = d1+100
		d2 = d2+100
		d3 = d3+100
		d4 = d4+100
		d5 = d5 +100
		d6 = d6+100
		d7 = d7+100
		d8 = d8+100
		d9 = d9+100
		d10 = d10+100
		d11 = d11-100
		d12 = d12-100
		d13 = d13-100
		d14 = d14-100
		d15 = d15 -100
		d16 = d16-100
		d17 = d17-100
		d18 = d18-100
		d19 = d19-100
		d20 = d20-100
		d21 = d21-100
		d22 = d22-100
		d23 = d23-100
		d24 = d24-100
		d25 = d25 -100
		e1 = e1-100
		e2 = e2+100
		e3 = e3-100
		e4 = e4+100
		e5 = e5 -100
		e6 = e6+100
		e7 = e7-100
		e8 = e8+100
		e9 = e9-100
		e10 = e10+100
		e11 = e11-100
		e12 = e12+100
		e13 = e13-100
		e14 = e14+100
		e15 = e15 -100
		e16 = e16+100
		e17 = e17-100
		e18 = e18+100
		e19 = e19-100
		e20 = e20+100
		e21 = e21-100
		e22 = e22+100
		e23 = e23-100
		e24 = e24+100
		e25 = e25 -100



		print("wh1")
		#functions to insert the data into the main_person table
		dbInsert1(c1,d1,e1,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c2,d2,e2,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c3,d3,e3,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c4,d4,e4,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c5,d5,e5,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c6,d6,e6,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c7,d7,e7,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c8,d8,e8,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c9,d9,e9,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c10,d10,e10,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c11,d11,e11,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c12,d12,e12,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c13,d13,e13,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c14,d14,e14,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c15,d15,e15,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c16,d16,e16,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c17,d17,e17,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c18,d18,e18,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c19,d19,e19,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c20,d20,e20,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c21,d21,e21,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c22,d22,e22,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c23,d23,e23,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c24,d24,e24,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c25,d25,e25,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		time.sleep(2)
		j= j+1
	j = 300
	while j > 200 :
		d1 = d1-100
		d2 = d2-100
		d3 = d3-100
		d4 = d4-100
		d5 = d5 -100
		d6 = d6-100
		d7 = d7-100
		d8 = d8-100
		d9 = d9-100
		d10 = d10-100

		d11 = d11+100
		d12 = d12+100
		d13 = d13+100
		d14 = d14+100
		d15 = d15 +100
		d16 = d16+100
		d17 = d17+100
		d18 = d18+100
		d19 = d19+100
		d20 = d20+100
		d21 = d21+100
		d22 = d22+100
		d23 = d23+100
		d24 = d24+100
		d25 = d25 +100
		e1 = e1+100

		e2 = e2-100

		e3 = e3+100
		e4 = e4-100

		e5 = e5 +100

		e6 = e6-100

		e7 = e7+100

		e8 = e8-100

		e9 = e9+100

		e10 = e10-100
		e11 = e11+100
		e12 = e12-100
		e13 = e13+100
		e14 = e14-100
		e15 = e15 +100
		e16 = e16-100
		e17 = e17+100
		e18 = e18-100
		e19 = e19+100
		e20 = e20-100
		e21 = e21+100
		e22 = e22-100
		e23 = e23+100
		e24 = e24-100
		e25 = d25 +100



		print("wh2")
		#functions to insert the data into the main_person table
		dbInsert1(c1,d1,e1,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c2,d2,e2,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c3,d3,e3,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c4,d4,e4,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c5,d5,e5,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c6,d6,e6,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c7,d7,e7,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c8,d8,e8,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c9,d9,e9,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c10,d10,e10,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c11,d11,e11,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c12,d12,e12,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c13,d13,e13,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c14,d14,e14,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c15,d15,e15,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c16,d16,e16,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c17,d17,e17,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c18,d18,e18,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c19,d19,e19,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c20,d20,e20,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c21,d21,e21,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c22,d22,e22,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c23,d23,e23,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c24,d24,e24,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		dbInsert1(c25,d25,e25,datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S"))
		time.sleep(2)
		j= j-1
	i = i+1
	






