import psycopg2
import pika
import datetime
global conn
conn = psycopg2.connect("dbname='smartbuilding' port='5432' user='amudalab3' host='172.17.137.160' password='amudalab'")
#connection string

def Insert_Raw_Data(mac, ax, ay, ex, ey, time, rv):
	try:		
		cur = conn.cursor()		
		cur.execute("INSERT INTO wifidata (mac,x_ref,y_ref,x,y,time,rssi_vector) VALUES (%s,%s,%s,%s,%s,%s,%s)",(mac,ax,ay,ex,ey,time,rv))
		#to insert rawdata in the table wifidata
		conn.commit()
	except:
		print("Connection Failed1")

def Insert_Location_Data(mac, ex, ey, time):
	try:
		cur = conn.cursor()		
		cur.execute("INSERT INTO main_person (mac,x,y,time,geom) VALUES (%s,%s,%s,%s,ST_SetSRID(ST_MakePoint(%s,%s),4326))",(mac,ex,ey,time,ex,ey))
		#to insert location data in the table main_person
		conn.commit()
		cur.close()
	except:
		print("Connection Failed2")

def callback(ch, method, properties, body):
	print(" [x] Received %r" % body)
	data = str(body).split(',')
	a = len(data)
	print(a)
	if a > 5:
		if data[1] != '':
			print(data[1],data[2])
			Insert_Raw_Data(data[0],data[1],data[2],data[3],data[4],data[5],0)
			Insert_Location_Data(data[0],data[3],data[4],data[5])

		else :
			Insert_Raw_Data(data[0],0,0,data[3],data[4],data[5],0)
			Insert_Location_Data(data[0],data[3],data[4],data[5])

	
#code to consume the data from the rabbitmq server
credentials = pika.PlainCredentials('amuda', 'amuda2017')
# ip should to used to connect to the rabbitmq server running in the remote machine
parameters = pika.ConnectionParameters('172.17.137.160',5672,'amudavhost',credentials)
connection = pika.BlockingConnection(parameters)
channel = connection.channel()
q = channel.queue_declare()
channel.queue_declare(queue = "", exclusive = True)
channel.queue_bind(exchange = "amq.fanout", queue = "", routing_key = None)
channel.basic_consume(callback, "",no_ack=True)
print(' [*] Waiting for messages. To exit press CTRL+C')
channel.start_consuming()


