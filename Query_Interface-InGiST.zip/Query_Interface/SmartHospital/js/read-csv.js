function handleFiles(files) {
	// Check for the various File API support.
	if (window.FileReader) {
		// FileReader are supported.
		getAsText(files[0]);
	} else {
		alert('FileReader are not supported in this browser.');
	}
}

function getAsText(fileToRead) {
	var reader = new FileReader();
	// Handle errors load
	reader.onload = loadHandler;
	reader.onerror = errorHandler;
	// Read file into memory as UTF-8      
	reader.readAsText(fileToRead);
}

function loadHandler(event) {
	var csv = event.target.result;
	processData(csv);
}

function processData(csv) {
	var allTextLines = csv.split(/\r\n|\n/);
	var lines = [];
	while (allTextLines.length) {
		lines.push(allTextLines.shift().split(','));
	}
	console.log(lines);
	drawOutput(lines);
}

function errorHandler(evt) {
	if (evt.target.error.name == "NotReadableError") {
		alert("Canno't read file !");
	}
}

function drawOutput(lines) {
	//Clear previous data
	document.getElementById("output").innerHTML = "";
	var table = document.createElement("table");
	for (var i = 0; i < lines.length; i++) {
		var row = table.insertRow(-1);
		for (var j = 0; j < lines[i].length; j++) {
			var firstNameCell = row.insertCell(-1);
			firstNameCell.appendChild(document.createTextNode(lines[i][j]));
		}
	}
	document.getElementById("output").appendChild(table);

	//send data to server
	parseCSVData(lines);

}

function parseCSVData(lines) {
	var jsonObj = {};
	jsonObj.metadata = {};
	jsonObj.data = [];
	var headers = new Array();
	if(lines==='reader'){}
	for (i in lines) {
		if (i < 4) {
			jsonObj.metadata[i] = lines[i];
		} else if (i == 4) {
			//let split = lines[i].split(",");
			for (j in lines[i]) {
				headers.push(lines[i][j]); lines
			}
		} else {
			//let split = lines[i].split(",");
			var element = {};
			for (k in lines[i]) {
				element[headers[k]] = lines[i][k];
			}
			jsonObj.data.push(element);
		}
	}
	console.log(jsonObj);
	sendCSVData(jsonObj);
}

function sendCSVData(jsonObj) {
	$.post("http://127.0.0.1:3333/csvdata", jsonObj, function (data, status) {
		
	});
	/*$.ajax({
    url: 'http://127.0.0.1:3333/csvdata',
    type: 'POST',
    data: JSON.stringify(jsonObj),
    contentType: 'application/json; charset=utf-8',
    dataType: 'json',
    async: false,
    success: function(msg) {
        alert(msg);
    }
});*/
}