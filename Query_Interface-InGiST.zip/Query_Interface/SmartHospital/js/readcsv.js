var jsonObj = { 'reader': {}, 'antenna': {}, 'connection': {}, 'router':{}};
var readerFileRead = false;
var antennaFileRead = false;
var connectionFileRead = false;
var routerFileRead = false;

//Default
function handleFiles(files, filetype) {
	// Check for the various File API support.
	if (window.FileReader) {
		// FileReader are supported.
		getAsText(files[0], filetype);
	} else {
		alert('FileReader are not supported in this browser.');
	}
}

function getAsText(fileToRead, filetype) {
	if (filetype == 'reader') {
		console.log('reader filetype');
		var reader = new FileReader();
		// Handle errors load
		reader.onload = loadHandler1;
		reader.onerror = errorHandler;
		// Read file into memory as UTF-8      
		reader.readAsText(fileToRead);
	} else if (filetype == 'antenna') {
		console.log('antenna filetype');
		var reader = new FileReader();
		// Handle errors load
		reader.onload = loadHandler2;
		reader.onerror = errorHandler;
		// Read file into memory as UTF-8      
		reader.readAsText(fileToRead);
	} else if (filetype == 'connection') {
		console.log('connection filetype');
		var reader = new FileReader();
		// Handle errors load
		reader.onload = loadHandler3;
		reader.onerror = errorHandler;
		// Read file into memory as UTF-8      
		reader.readAsText(fileToRead);
	}
	else if(filetype == 'router'){
		var reader = new FileReader();
		reader.onload = loadHandler4;
		reader.onerror = errorHandler;
		reader.readAsText(fileToRead);
	}
}

function loadHandler1(event) {
	console.log('reader loadHandler1');
	var csv = event.target.result;
	processData(csv, 'reader');
}

function loadHandler2(event) {
	console.log('antenna loadHandler2');
	var csv = event.target.result;
	processData(csv, 'antenna');
}

function loadHandler3(event) {
	console.log('connection loadHandler3');
	var csv = event.target.result;
	processData(csv, 'connection');
}

function loadHandler4(event) {
	console.log('router loadHandler4');
	var csv = event.target.result;
	processData(csv, 'router');
}

function processData(csv, filetype) {
	console.log('processData : ' + filetype);
	var allTextLines = csv.split(/\r\n|\n/);
	var lines = [];
	while (allTextLines.length) {
		lines.push(allTextLines.shift().split(','));
	}
	parseCSVData(lines, filetype);
}

function errorHandler(evt) {
	if (evt.target.error.name == "NotReadableError") {
		alert("Canno't read file !");
	}
}


function parseCSVData(lines, filetype) {
	if (filetype == 'reader') {
		var readerObj = {}
		readerObj.metadata = {};
		readerObj.data = [];
		var headers = new Array();
		for (let i in lines) {
			if (i == 0) {
				for (j in lines[i]) {
					headers.push(lines[i][j]);
				}
			} else {
				var element = {};
				console.log("isLineEmpty(lines[i]) : "+isLineEmpty(lines[i]))
				if (!isLineEmpty(lines[i])) {
					for (k in lines[i]) {
						element[headers[k]] = lines[i][k];
					}
					readerObj.data.push(element);
				}
			}
		}
		console.log('reader : ');
		console.log(readerObj);
		jsonObj.reader = readerObj;
		readerFileRead = true;
	} else if (filetype == 'antenna') {
		var antennaObj = {}
		antennaObj.metadata = {};
		antennaObj.data = [];
		var headers = new Array();
		for (i in lines) {
			if (i == 0) {
				for (j in lines[i]) {
					headers.push(lines[i][j])
				}
			} else {
				var element = {};
				if (!isLineEmpty(lines[i])) {
					for (k in lines[i]) {
						element[headers[k]] = lines[i][k];
					}
					antennaObj.data.push(element);
				}
			}
		}
		console.log('antenna : ' + antennaObj);
		jsonObj.antenna = antennaObj;
		antennaFileRead = true;
	} else if (filetype == 'connection') {
		var connectionObj = {}
		connectionObj.metadata = {};
		connectionObj.data = [];
		var headers = new Array();
		for (i in lines) {
			if (i == 0) {
				for (j in lines[i]) {
					headers.push(lines[i][j]);
				}
			} else {
				var element = {};
				if (!isLineEmpty(lines[i])) {
					for (k in lines[i]) {
						element[headers[k]] = lines[i][k];
					}
					connectionObj.data.push(element);
				}
			}
		}
		console.log('connection : ' + connectionObj);
		jsonObj.connection = connectionObj;
		connectionFileRead = true;
	}
	else if (filetype == 'router') {
		var routerObj = {}
		routerObj.metadata = {};
		routerObj.data = [];
		var headers = new Array();
		for (i in lines) {
			if (i == 0) {
				for (j in lines[i]) {
					headers.push(lines[i][j]);
				}
			} else {
				var element = {};
				if (!isLineEmpty(lines[i])) {
					for (k in lines[i]) {
						element[headers[k]] = lines[i][k];
					}
					routerObj.data.push(element);
				}
			}
		}
		console.log('router : ' + routerObj);
		jsonObj.router = routerObj;
		routerFileRead = true;
	}
}

function sendCSVData() {
	if (readerFileRead || antennaFileRead || connectionFileRead || routerFileRead) {
		console.log('sendCSVData jsonObj: ');
		console.log(jsonObj);
		$.post("http://127.0.0.1:3333/csvconfigdata", jsonObj, function (data, status) {
			console.log(data);
		});
	} else {
		console.log('Still reading file, try a few seconds later.....')
	}
}

function isLineEmpty(linesi) {
	let r = true;
	for (k in linesi) {
		if (linesi[k]) {
			return false;
		}else{
			r = true;
		}
	}
	return r;
}