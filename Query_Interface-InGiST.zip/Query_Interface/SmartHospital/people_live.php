<html>

<head>
    <title>Introduction</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content-type="width=device-width, initial-scale=0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="combined.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.0.3/dist/leaflet.css" integrity="sha512-07I2e+7D8p6he1SIM+1twR5TIrhUQn9+I6yjqD53JQjFiMf8EtC93ty0/5vJTZGF8aAocvHYNEDJajGdNx1IsQ==" crossorigin="" />
    <link rel="stylesheet" href="http://code.ionicframework.com/ionicons/1.5.2/css/ionicons.min.css">
    <script src="https://unpkg.com/leaflet@1.0.3/dist/leaflet.js" integrity="sha512-A7vV8IFfih/D732iSSKi20u/ooOfj/AGehOKq0f4vLT1Zr2Y+RX7C+w8A1gaSasGtRUZpF/NZgzSAu4/Gc41Lg==" crossorigin=""></script>
    <link rel="stylesheet" href="leaflet.awesome-markers.css">
    <script src="leaflet.awesome-markers.js"></script>
    <script src="js/leaflet-0.7.2/leaflet.ajax.min.js"></script>
   
    <script src="/js/bootstrap-datetimepicker.js"></script>
    <script src="/js/bootstrap.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <link href="/css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
    <script type="text/javascript" src="/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
    <script type="text/javascript" src="/js/locales/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>
    <script src ="/js/leaflet-color-markers.js"></script>
    <link rel="stylesheet" href="/fontawesome/css/font-awesome.min.css">
    <script src = "/server.js"></script>
    <script src = "/function.js"></script>
    <style>
    .ryt{

   position:fixed;
   right:50px;
   top: 70px;
   
}
    </style>
 
</head>

<body>


<h1 align="center"> <span>I</span>nGIST <span>L</span>ive <span>T</span>racking</h1>

<div style="width:100%;"> <!-- Main Div -->

    <div style="float:left; width:100%;">
        <div class="wthree-text"  > 
        <form action="people_live.php" method="post">
            <ul>
            <div class="row" hidden>

                                        <div class='col-md-2'>
                                            <div class="form-group">
                                                <div class='input-group date' id='datetimepicker1'>
                                                    <input type='text' class="form-control" id = "t1" name = "t1" value="<?php echo isset($_POST['t1']) ? $_POST['t1'] : '' ?>" />
                                                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <script type="text/javascript">
                                            $(function() {
                                                $('#datetimepicker1').datetimepicker({
                                                    locale: 'in',
                                                    format: "yyyy-mm-dd hh:ii:00"
                                                     
                                                });
                                            });
                                            

                                        </script>
                                 
                              
                          

                            
                            
                                
                                    

                                        <div class='col-md-2'>
                                            <div class="form-group">
                                                <div class='input-group date' id='datetimepicker2'>
                                                    <input type='text' class="form-control" id = "t2" name = "t2" value="<?php echo isset($_POST['t2']) ? $_POST['t2'] : '' ?>" hidden/>
                                                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <script type="text/javascript">
                                            $(function() {
                                                $('#datetimepicker2').datetimepicker({
                                                    locale: 'in',
                                                    format: "yyyy-mm-dd hh:ii:00"
                                                    
                                                });
                                            });

                                        </script>

                </div>
            <select id="fid" onchange="loadmap()" hidden>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
            </select>
            <select id="track" onchange="loadcategory()" required>
                <option selected="selected" value = "all">--Asset/People--</option>
                <option value="People">People</option>
                <option value="Asset">Asset</option>
            </select>
            <select id="category" name="category"  onchange="loadmac()" required>
                <option selected="selected">--Category--</option>
            </select>
            <select id="mac" name="mac" required>
                <option selected="selected">--ID--</option>  
                <option value = "All">All</option>  
            </select>
                <input type="button" value="Track" name="Track" id = "Track" class="btn btn-success" onclick="option()">
                <input type="submit"  Value = "Stop" id = "stoptracking"class="btn hide">
                
                <label class="ryt">
                    <input type="button" value="Asset Queries" name=querya id = "querya" class="btn btn-success">
                <input type="button" value="People Queries" name=queryp id = "queryp" class="btn btn-success">
                </label>
            </ul>
        </form>
            
           
        </div>
          <div class="modal fade" id="peoplelive" name = "peoplelive" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        
                            <form action="people_live.php" method="post">
                    <div class="wthree-text" id = "roomdiv">
                        
                            &nbsp; &nbsp;<label>Display all</label>
                            <select id="person_category2" name="person_category2" >
                            </select>
                            <label>in Location</label>
                            <select id="room1" name="room1">
                            </select>
                             <input type="button" value="Find" name="findallinroom" id ="findallinroomb" class="btn btn-success" onclick="findroom()">                     
                            <input type="submit"  Value = "Stop" id ="stopallinroom" class="btn hide">                 
                    </div>
                    </form>
                    
                    
                    <form action="people_live.php" method="post">
                                                                                
                    <div class="wthree-text" id = "crowddiv">
                        
                            &nbsp; &nbsp;<label>Display</label>
                            <select name ="crowd" id = "crowd">
								<option value="Most">Most</option>
								<option value="Least">Least</option>
                        	</select>
                            <label>occupied Location</label>
                            <input type="submit" value="Locate" name="Locate2" id ="Locate2b" class="btn btn-success"> 
                                        <input type="submit"  Value = "Stop" id ="Locate2bs" class="btn hide">
                    </div>
                    </form>
                    

                    <form action="people_live.php" method="post" name="disform">
                                               
                        <div class="wthree-text" id = "d1div">                          
                                &nbsp; &nbsp;<label>Distance Between</label>
                                <select id="person_category3" name="person_category3" onchange = "loadmac2()">
                            </select>
                                <select id="mac2" name="mac2" required>
                            </select>
                                <label>and</label>
                                <select id="person_category4" name="person_category4" onchange = "loadmac3()">
                            </select>
                                <select id="mac3" name="mac3" required>
                            </select>
                                <input type="submit" value="calculate" name="calculated1" id ="calculated1b" class="btn btn-success">                                           <input type="submit"  Value = "Stop" id ="calculated1bs" class="btn hide">
                        </div>
                    </form>
                    
                    
                    <form action="people_live.php" method="post">
                                                                       
                    <div class="wthree-text" id = "d2div">
                       
                            &nbsp; &nbsp;<label>Distance Between</label>
                            <select id="person_category5" name="person_category5" onchange = "loadmac4()">
                            </select>
                            <select id="mac4" name="mac4" required >
                            </select>
                            <label>and Location</label>
                            <select id="room2" name="room2" required >
                            </select>
                            <input type="submit" value="calculate" name="calculated2" id = "calculated2b" class="btn btn-success">    
                                        <input type="submit"  Value = "Stop" id = "calculated2bs" class="btn hide">
                    </div>
                    </form>
                    
                    <form action="people_live.php" method="post" name="form3">
                        
                        <div class="wthree-text" id = "findmdiv">
                           
                                &nbsp; &nbsp;<label>Display</label>
                                <select id="person_category6" name="person_category6" >
                            </select>
                                <label>within</label>
                                <select id="meters1" name="meters1">
                            <?php
                                for ($i=1; $i<=100; $i++)
                                {
                                    ?>
                                        <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                    <?php
                                }
                            ?>
                            </select>
                                <label>meters of</label>
                                <select id="person_category8" name="person_category8" onchange = "loadmac5()">
                            </select>
                                <select id="mac5" name="mac5" required >
                            </select>
                                <input type="button" value="find" name="find" id = "findm2b"class="btn btn-success" onclick="findm()">                                          <input type="submit"  Value = "Stop" id = "findm2bs"class="btn hide">  
                        </div>
                    </form>
                    
                    <form action="people_live.php" method="post" name="form3">
                    <div class="wthree-text" id = "findm1div">
                     
                            &nbsp; &nbsp;<label>Display</label>
                            <select id="person_category7" name="person_category7" >
                            </select>
                            <label>within</label>
                            <select id="meters2" name="meters2">
                            <?php
                                for ($i=1; $i<=100; $i++)
                                {
                                    ?>
                                        <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                    <?php
                                }
                            ?>
                            </select>
                            <label>meters of Location</label>
                            <select id="room3" name="room3">
                            </select>
                            <select id="fid" onchange="loadmap()" hidden>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
                            </select>
                            <input type="button" value="find" name="find" id = "findm1b" class="btn btn-success" onclick="findm1()">                       
                                    <input type="submit"  Value = "Stop" id = "findm1bs" class="btn hide">
                        </div>
                    </form>
                    
                    

                    

                    <form action="people_live.php" method="post" name="k1form">
                       

                        <div class="wthree-text" id = "k1div">
                            
                                &nbsp; &nbsp;<label>Display</label>
                                <select id="k1" name="k1" >
                            <?php
                                for ($i=1; $i<=100; $i++)
                                {
                                    ?>
                                        <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                    <?php
                                }
                            ?>
                            </select>
                                <label>Nearest</label>
                                <select id="person_category9" name="person_category9">
                            </select>
                                <label>to</label>
                                <select id="person_category10" name="person_category10" onchange = "loadmac6()">
                            </select>
                                <select id="mac6" name="mac6" required>
                            </select>
                                <input type="button" value="find" name="k1find" id = "findkb"class="btn btn-success" onclick="findk()">                                     <input type="submit"  Value = "Stop" id = "findkbs"class="btn hide">
                        </div>
                    </form>
                    
                    <form action="people_live.php" method="post" name="k2form">
                    <div class="wthree-text" id = "k2div">
                      
                           &nbsp; &nbsp;<label>Display</label>
                            <select id="k2" name="k2">
                            <?php
                                for ($i=1; $i<=100; $i++)
                                {
                                    ?>
                                        <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                    <?php
                                }
                            ?>
                            </select>
                            <label>Nearest</label>
                            <select id="person_category11" name="person_category11" >
                            </select>
                            <label>to Location</label>
                            <select id="room4" name="room4" required>
                            </select>
                            <input type="button" value="find" name="k1find" id = "findk1b"class="btn btn-success" onclick="findk1()">                                        <input type="submit"  Value = "Stop"  id = "findk1bs"class="btn hide">
                    </div>
                    </form>

                   
                    <form action="people_live.php" method="post" name="c1form">
                    <div class="wthree-text" id = "c1div">
                       
                            &nbsp; &nbsp;<label>Count</label>
                            <select id="person_category15" name="person_category15" >
                            </select>
                            <label>in</label>
                            <select id="room5" name="room5" required>
                            </select>
                             <input type="submit" value="count" name="count1" id = "count1b"class="btn btn-success" >   
                                        <input type="submit"  Value = "Stop" id = "count1bs"class="btn hide">
                    </div>
                    </form>
                    <form action="people_live.php" method="post" name="c2form">
                    <div class="wthree-text" id = "c2div">
                        
                            &nbsp; &nbsp;<label>Count</label>
                            <select id="person_category16" name="person_category16" >
                            </select>
                            <label>within</label>
                            <select id="meters3" name="meters3">
                            <?php
                                for ($i=1; $i<=100; $i++)
                                {
                                    ?>
                                        <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                    <?php
                                }
                            ?>
                            </select>
                            <label>meters of Location</label>
                            <select id="room6" name="room6" required>
                            </select>
                             <input type="submit" value="count" name="count2" id = "count2b"class="btn btn-success" >
                                        <input type="submit"  Value = "Stop" id = "count2bs" class="btn hide">
                    </div>
                    </form>
    </div>
              </div>
        </div>
        
        
        
                  <div class="modal fade" id="assetlive" name = "assetlive" role="dialog" >
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
          <form action="people_live.php" method="post">
                    <div class="wthree-text">
                        <ul>
                            <label>Display all</label>
                            <select id="asset_category2" name="asset_category2" style="width:120px">
                            </select>
                            <label>in Location</label>
                            <select id="roomA1" name="roomA1" required>
                            </select>
                            <input type="button" value="Find" name="findallinrooma" id ="findallinroomba" class="btn btn-success" onclick="findinra()">                     
                            <input type="submit"  Value = "Stop" id ="stopallinrooma" class="btn hide">  
                        
                        </ul>
                    </div>
                    </form>
                    

                    

                    <form action="people_live.php" method="post" name="disform">
                                               
                        <div class="wthree-text">
                            <ul>
                                <label>Distance Between</label>
                                <select id="asset_category3" name="asset_category3" onchange = "loadepc1()" style="width:120px">
                            </select>
                                <select id="epc2" name="epc2" required style="width:160px">
                            </select>
                                <label>and</label>
                                <select id="asset_category4" name="asset_category4" onchange = "loadepc2()" style="width:120px">
                            </select>
                                <select id="epc3" name="epc3" required style="width:160px">
                            </select>
                                <input type="submit" value="calculate" name="calculateda1" id = "calculated1ba" class="btn btn-success">
                            </ul>
                        </div>
                    </form>
                    
                    
                    <form action="people_live.php" method="post">
                                                                       
                    <div class="wthree-text">
                        <ul>
                            <label>Distance Between</label>
                            <select id="asset_category5" name="asset_category5" onchange = "loadepc3()" style="width:120px">
                            </select>
                            <select id="epc4" name="epc4" required style="width:160px">
                            </select>
                            <label>and Location</label>
                            <select id="roomA2" name="roomA2" required style="width:160px">
                            </select>
                            <input type="submit" value="calculate" name="calculateda2" id = "calculated2ba" class="btn btn-success">
                        </ul>
                    </div>
                    </form>
                    
                    <form action="people_live.php" method="post" name="form3">
                        
                        <div class="wthree-text">
                            <ul>
                                <label>Display</label>
                                <select id="asset_category7" name="asset_category7" style="width:120px">
                            </select>
                                <label>within</label>
                                <select id="metersa1" name="metersa1" >
                            <?php
                                for ($i=1; $i<=100; $i++)
                                {
                                    ?>
                                        <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                    <?php
                                }
                            ?>
                            </select>
                                <label>meters of</label>
                                <select id="asset_category8" name="asset_category8" onchange = "loadepc4()" style="width:120px">
                            </select>
                                <select id="epc5" name="epc5" required style="width:160px">
                            </select>
                                <input type="button" value="find" name="find" id = "findm2ba"class="btn btn-success" onclick="findma()">                                          
                                <input type="submit"  Value = "Stop" id = "findm2bsa"class="btn hide">  
                        
                            </ul>
                        </div>
                    </form>
                    
                    <form action="people_live.php" method="post" name="form3">
                    <div class="wthree-text">
                        <ul>
                            <label>Display</label>
                            <select id="asset_category6" name="asset_category6" style="width:120px">
                            </select>
                            <label>within</label>
                            <select id="metersa2" name="metersa2" >
                            <?php
                                for ($i=1; $i<=100; $i++)
                                {
                                    ?>
                                        <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                    <?php
                                }
                            ?>
                            </select>
                            <label>meters of Location</label>
                            <select id="roomA3" name="roomA3"  style="width:160px">
                            </select>
                            <select id="fid" onchange="loadmap()" hidden>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
                            </select>
                                <input type="button" value="find" name="find" id = "findm1ba" class="btn btn-success" onclick="findma1()">                       
                                    <input type="submit"  Value = "Stop" id = "findm1bsa" class="btn hide">
                        </ul>
                    </div>
                    </form>
                    
                    

                    

                    <form action="people_live.php" method="post" name="k1form">
                       

                        <div class="wthree-text">
                            <ul>
                                <label>Display</label>
                                <select id="ka1" name="ka1">
                            <?php
                                for ($i=1; $i<=100; $i++)
                                {
                                    ?>
                                        <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                    <?php
                                }
                            ?>
                            </select>
                                <label>Nearest</label>
                                <select id="asset_category9" name="asset_category9" style="width:120px">
                            </select>
                                <label>to</label>
                                <select id="asset_category10" name="asset_category10"  onchange = "loadepc5()" style="width:120px">
                            </select>
                                <select id="epc6" name="epc6" required  style="width:160px">
                            </select>
                            
                                <input type="button" value="find" name="k1find" id = "findkba"class="btn btn-success" onclick="findka()">                                    
                                <input type="submit"  Value = "Stop" id = "findkbsa"class="btn hide">
                            </ul>
                        </div>
                    </form>
                    
                    <form action="people_live.php" method="post" name="k2form">
                    <div class="wthree-text">
                        <ul>
                            <label>Display</label>
                            <select id="ka2" name="ka2">
                            <?php
                                for ($i=1; $i<=100; $i++)
                                {
                                    ?>
                                        <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                    <?php
                                }
                            ?>
                            </select>
                            <label>Nearest</label>
                            <select id="asset_category11" name="asset_category11" style="width:120px" >
                            </select>
                            <label>to Location</label>
                            <select id="roomA4" name="roomA4" required>
                            </select>
                            <input type="button" value="find" name="k1find" id = "findk1ba"class="btn btn-success" onclick="findka1()">                                        
                            <input type="submit"  Value = "Stop"  id = "findk1bsa"class="btn hide">
                        </ul>
                    </div>
                    </form>

                   
                    <form action="people_live.php" method="post" name="c1form">
                    <div class="wthree-text">
                        <ul>
                            <label>Count</label>
                            <select id="asset_category15" name="asset_category15" style="width:120px" >
                            </select>
                            <label>in</label>
                            <select id="roomA5" name="roomA5" required>
                            </select>
                             <input type="submit" value="count" name="counta1" id = "count1ba" class="btn btn-success" >
                        </ul>
                    </div>
                    </form>
                    <form action="people_live.php" method="post" name="c2form">
                    <div class="wthree-text"> 
                        <ul>
                            <label>Count</label>
                            <select id="asset_category16" name="asset_category16" style="width:120px" >
                            </select>
                            <label>within</label>
                            <select id="metersa3" name="metersa3">
                            <?php
                                for ($i=1; $i<=100; $i++)
                                {
                                    ?>
                                        <option value="<?php echo $i;?>"><?php echo $i;?></option>
                                    <?php
                                }
                            ?>
                            </select>
                            <label>meters of Location</label>
                            <select id="roomA6" name="roomA6" required>
                            </select>
                             <input type="submit" value="count" name="counta2" id = "count2ba" class="btn btn-success" >
                        </ul>

                    </div>
                    </form>
            </div>
              </div>
        </div>
        
        

    </div>
<div style="float:left; width:100%; margin-left:10px;" id = "map">

</div>
</div>
    
    <script>
                
$(document).ready(function(){
    $("#queryp").click(function(){
        $("#peoplelive").modal();
       // document.getElementById("querya").disabled = true;
    });
    

    $("#querya").click(function(){
        $("#assetlive").modal();
       // document.getElementById("queryp").disabled = true;
    });
});
        
loadmap();

          

        
function enableButton2() {
                    $('#Track').removeClass('btn-success');
         $('#Track').addClass('hide');
        $('#stoptracking').removeClass('hide');
        $('#stoptracking').addClass('btn-success');
            document.getElementById("querya").disabled = true;
            document.getElementById("queryp").disabled = true;
        }
        
function enableButton() {
    document.getElementById("findallinroomb").disabled = true;
     document.getElementById("Locate2b").disabled = true;
    document.getElementById("calculated1b").disabled = true;
    document.getElementById("calculated2b").disabled = true;
    document.getElementById("findm2b").disabled = true;
    document.getElementById("findm1b").disabled = true;
        document.getElementById("findkb").disabled = true;
    document.getElementById("findk1b").disabled = true;
            document.getElementById("count1b").disabled = true;
    document.getElementById("count2b").disabled = true;
    
        document.getElementById("findallinroomba").disabled = true;
    document.getElementById("calculated1ba").disabled = true;
    document.getElementById("calculated2ba").disabled = true;
    document.getElementById("findm2ba").disabled = true;
    document.getElementById("findm1ba").disabled = true;
        document.getElementById("findkba").disabled = true;
    document.getElementById("findk1ba").disabled = true;
            document.getElementById("count1ba").disabled = true;
    document.getElementById("count2ba").disabled = true;
    
    
}
        
        
function onEachFeature(feature, layer) {
    if (feature.properties) {
        //layer.bindPopup(feature.properties);
    }
}


var map = L.map('map', {
    crs: L.CRS.Simple,
    noWrap: true,
    minZoom: -10000
}).setView([730304, 215616], 13);


function addJSONDataToMap(dataURL) {
    $.getJSON(dataURL, function(jsondata) {
        console.log(jsondata);
        let layer = L.geoJson(jsondata).addTo(map);
        console.log('layer.getBounds() : ');
        console.log(layer.getBounds());
        //boundsArray.push(layer.getBounds());
        map.fitBounds(layer.getBounds());
    });
}


function loadmap() {
    var currentFloor = $("#fid option:selected").val();
    console.log(currentFloor);
    $.getJSON('http://172.17.137.160:3333/floor/' + currentFloor, function(data) {
        console.log(data);
        for (i in data.files) {
            console.log(data.files[i]);
            addJSONDataToMap(data.files[i]);
        }
    });
}

var loadcategory = function () {
     var tr = $("#track option:selected").val();
if(tr == "People"){

$.getJSON('http://172.17.137.160:3333/person_category', function (data) {
         $('#category').empty();

    $("#category").append('<option value="All">All</option>');
                                 $('#mac').empty();
    $("#mac").append('<option value="All">All</option>');

    $.each(data, function(mac, item) {

    $('#category').append(
        $('<option></option>').val(item.person_category).html(item.person_category)
    );


      });



    });
}
else if(tr == "Asset"){
                $.getJSON('http://172.17.137.160:3333/asset_category', function (data) {
                             $('#category').empty();

    $("#category").append('<option value="All">All</option>');
                             $('#mac').empty();
    $("#mac").append('<option value="All">All</option>');
                        $.each(data, function(mac, item) {

    $('#category').append(
        $('<option></option>').val(item.asset_category).html(item.asset_category)
    );
                            });


    });

}

};


var loadmac = function () {
         var tr = $("#track option:selected").val();
      var pc = $("#category option:selected").val();
if(tr =="People"){

$.getJSON('http://172.17.137.160:3333/mac/' +pc, function (data) {
         $('#mac').empty();
    // $("#mac").append('<option selected="selected">--ID--</option>');
    $("#mac").append('<option value="All">All</option>');



    $.each(data, function(mac, item) {

    $('#mac').append(
        $('<option></option>').val(item.mac).html(item.mac)
    );


      });



    });
}
else if(tr =="Asset"){

$.getJSON('http://172.17.137.160:3333/epc/' +pc, function (data) {
         $('#mac').empty();
     //$("#mac").append('<option selected="selected">--ID--</option>');
    $("#mac").append('<option value="All">All</option>');



    $.each(data, function(epc, item) {

    $('#mac').append(
        $('<option></option>').val(item.epc).html(item.epc)
    );


      });



    });
}
    

};        
var loadmac1 = function () {
         var pc = $("#person_category1 option:selected").val();
    $.getJSON('http://172.17.137.160:3333/mac/' +pc, function (data) {
        $('#mac1').empty();
        $('#mac2').empty();
        $('#mac3').empty();
        $('#mac4').empty();
        $('#mac5').empty();
        $('#mac6').empty();
        $.each(data, function(mac, item) {

        $('#mac1').append(
            $('<option></option>').val(item.mac).html(item.mac)
        );

          });

        });

};
var loadmac2 = function () {
         var pc = $("#person_category3 option:selected").val();
    $.getJSON('http://172.17.137.160:3333/mac/' +pc, function (data) {
        $('#mac1').empty();
        $('#mac2').empty();
        $('#mac4').empty();
        $('#mac5').empty();
        $('#mac6').empty();
        $.each(data, function(mac, item) {

        $('#mac2').append(
            $('<option></option>').val(item.mac).html(item.mac)
        );

          });

        });

};
var loadmac3 = function () {

         var pc = $("#person_category4 option:selected").val();
    $.getJSON('http://172.17.137.160:3333/mac/' +pc, function (data) {
        $('#mac1').empty();
        $('#mac3').empty();
        $('#mac4').empty();
        $('#mac5').empty();
        $('#mac6').empty();
        $.each(data, function(mac, item) {

        $('#mac3').append(
            $('<option></option>').val(item.mac).html(item.mac)
        );

          });

        });

};
var loadmac4 = function () {

         var pc = $("#person_category5 option:selected").val();
    $.getJSON('http://172.17.137.160:3333/mac/' +pc, function (data) {
        $('#mac1').empty();
        $('#mac2').empty();
        $('#mac3').empty();
        $('#mac4').empty();
        $('#mac5').empty();
        $('#mac6').empty();
        $.each(data, function(mac, item) {

        $('#mac4').append(
            $('<option></option>').val(item.mac).html(item.mac)
        );

          });

        });

};
var loadmac5 = function () {
         var pc = $("#person_category8 option:selected").val();
    $.getJSON('http://172.17.137.160:3333/mac/' +pc, function (data) {
        $('#mac1').empty();
        $('#mac2').empty();
        $('#mac3').empty();
        $('#mac4').empty();
        $('#mac5').empty();
        $('#mac6').empty();
        $.each(data, function(mac, item) {

        $('#mac5').append(
            $('<option></option>').val(item.mac).html(item.mac)
        );

          });

        });

};
var loadmac6 = function () {
         var pc = $("#person_category10 option:selected").val();
    $.getJSON('http://172.17.137.160:3333/mac/' +pc, function (data) {
        $('#mac1').empty();
        $('#mac2').empty();
        $('#mac3').empty();
        $('#mac4').empty();
        $('#mac5').empty();
        $('#mac6').empty();
        $.each(data, function(mac, item) {

        $('#mac6').append(
            $('<option></option>').val(item.mac).html(item.mac)
        );

          });

        });

};

var loadepc1 = function () {
         var pc = $("#asset_category3 option:selected").val();
    $.getJSON('http://172.17.137.160:3333/epc/' + pc, function (data) {
        $('#epc1').empty();
        $('#epc2').empty();
        //$('#epc3').empty();
        $('#epc4').empty();
        $('#epc5').empty();
        $('#epc6').empty();
        $.each(data, function(epc, item) {

        $('#epc2').append(
            $('<option></option>').val(item.epc).html(item.epc)
        );

          });

        });

};
var loadepc2 = function () {

         var pc = $("#asset_category4 option:selected").val();
    $.getJSON('http://172.17.137.160:3333/epc/' +pc, function (data) {
        $('#epc1').empty();
        //$('#epc2').empty();
        $('#epc3').empty();
        $('#epc4').empty();
        $('#epc5').empty();
        $('#epc6').empty();
        $.each(data, function(epc, item) {

        $('#epc3').append(
            $('<option></option>').val(item.epc).html(item.epc)
        );

          });

        });

};
var loadepc3 = function () {

         var pc = $("#asset_category5 option:selected").val();
    $.getJSON('http://172.17.137.160:3333/epc/' +pc, function (data) {
        $('#epc1').empty();
        $('#epc2').empty();
        $('#epc3').empty();
        $('#epc4').empty();
        $('#epc5').empty();
        $('#epc6').empty();
        $.each(data, function(epc, item) {

        $('#epc4').append(
            $('<option></option>').val(item.epc).html(item.epc)
        );

          });

        });

};
var loadepc4 = function () {
         var pc = $("#asset_category8 option:selected").val();
    $.getJSON('http://172.17.137.160:3333/epc/' +pc, function (data) {
        $('#epc1').empty();
        $('#epc2').empty();
        $('#epc3').empty();
        $('#epc4').empty();
        $('#epc5').empty();
        $('#epc6').empty();
        $.each(data, function(epc, item) {

        $('#epc5').append(
            $('<option></option>').val(item.epc).html(item.epc)
        );

          });

        });

};
var loadepc5 = function () {
         var pc = $("#asset_category10 option:selected").val();
    $.getJSON('http://172.17.137.160:3333/epc/' +pc, function (data) {
        $('#epc1').empty();
        $('#epc2').empty();
        $('#epc3').empty();
        $('#epc4').empty();
        $('#epc5').empty();
        $('#epc6').empty();
        $.each(data, function(epc, item) {

        $('#epc6').append(
            $('<option></option>').val(item.epc).html(item.epc)
        );

          });

        });

};     


        

        
$.getJSON("http://172.17.137.160:3333/roomid", function(data) {
$.each(data, function(room_name, item) {
$('#room1').append(
$('<option></option>').val(item.room_name).html(item.room_name)
);
$('#room2').append(
$('<option></option>').val(item.room_name).html(item.room_name)
);
$('#room3').append(
$('<option></option>').val(item.room_name).html(item.room_name)
);
$('#room4').append(
$('<option></option>').val(item.room_name).html(item.room_name)
);
$('#room5').append(
$('<option></option>').val(item.room_name).html(item.room_name)
);
$('#room6').append(
$('<option></option>').val(item.room_name).html(item.room_name)
);
$('#roomr').append(
$('<option></option>').val(item.room_name).html(item.room_name)
);
$('#roomA1').append(
$('<option></option>').val(item.room_name).html(item.room_name)
);
$('#roomA2').append(
$('<option></option>').val(item.room_name).html(item.room_name)
);
$('#roomA3').append(
$('<option></option>').val(item.room_name).html(item.room_name)
);
$('#roomA4').append(
$('<option></option>').val(item.room_name).html(item.room_name)
);
$('#roomA5').append(
$('<option></option>').val(item.room_name).html(item.room_name)
);
$('#roomA6').append(
$('<option></option>').val(item.room_name).html(item.room_name)
);
});
});


$.getJSON("http://172.17.137.160:3333/person_category", function(data) {
$.each(data, function(person_category, item) {
$('#person_category1').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category2').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category3').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category4').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category5').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category6').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category7').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category8').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category9').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category10').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category11').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category12').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category13').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category14').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category15').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);
$('#person_category16').append(
$('<option></option>').val(item.person_category).html(item.person_category)
);

});
});
        

$.getJSON("http://172.17.137.160:3333/asset_category", function(data) {
$.each(data, function(asset_category, item) {
$('#asset_category1').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category2').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category3').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category4').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category5').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category6').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category7').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category8').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category9').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category10').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category11').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category12').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category13').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category14').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category15').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);
$('#asset_category16').append(
$('<option></option>').val(item.asset_category).html(item.asset_category)
);

});
});
        
        

jQuery(document).ready(function(){

jQuery('select#mac1').val('<?php echo $_POST[''];?>');

});
        
      
jQuery(document).ready(function(){

jQuery('select#crowd').val('<?php echo $_POST[''];?>');

});
  
        
        
jQuery(document).ready(function(){

jQuery('select#mac2').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#mac3').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#mac4').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#mac5').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#mac6').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#mac7').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#mac8').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#mac9').val('<?php echo $_POST[''];?>');

});

jQuery(document).ready(function(){

jQuery('select#room1').val('<?php echo $_POST[''];?>');

});
        
jQuery(document).ready(function(){

jQuery('select#room2').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#room3').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#room4').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#room5').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#room6').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category1').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category2').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category3').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category4').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category5').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category6').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category7').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category8').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category9').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category10').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category11').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category12').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category13').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category14').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category15').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#person_category16').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#meters1').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#meters2').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#meters3').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#k1').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#k2').val('<?php echo $_POST[''];?>');

});
        
        
jQuery(document).ready(function(){

jQuery('select#epc2').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#epc3').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#epc4').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#epc5').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#epc6').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#roomA1').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#roomA2').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#roomA3').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#roomA4').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#roomA5').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#roomA6').val('<?php echo $_POST[''];?>');

});
        
        
jQuery(document).ready(function(){

jQuery('select#asset_category1').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#asset_category2').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#asset_category3').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#asset_category4').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#asset_category5').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#asset_category6').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#asset_category7').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#asset_category8').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#asset_category9').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#asset_category10').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#asset_category11').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#asset_category12').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#asset_category15').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#asset_category16').val('<?php echo $_POST[''];?>');

});
        
jQuery(document).ready(function(){

jQuery('select#ka1').val('<?php echo $_POST[''];?>');

});

jQuery(document).ready(function(){

jQuery('select#ka2').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#metersa3').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#metersa1').val('<?php echo $_POST[''];?>');

});
jQuery(document).ready(function(){

jQuery('select#metersa2').val('<?php echo $_POST[''];?>');

});


//disabling the previous dropdown after the selection of next dropdown        
$('#category').on('change',function(){

$('#track').attr('disabled',true);
});
        
$('#id').on('change',function(){

$('#category').attr('disabled',true);
});

$('#Track').on('click',function(){
 var tr = $("#track option:selected").val();   
if(tr != '--Asset/People--'){
$('#id').attr('disabled',true);
$('#category').attr('disabled',true);
$('#track').attr('disabled',true);
}
});

        
        
var oneLayer = new L.geoJson();
//Add GeoJSON layer to map
map.addLayer(oneLayer);
        
var twoLayer = new L.geoJson();
//Add GeoJSON layer to map
map.addLayer(twoLayer);

//Create polygon
var polygon1 = L.polygon([
[194284.985381794 , 691284.232714891],
[ 194284.985381794,698809.232714867],
[183034.985381794,698809.232714867],
[183034.985381794,691284.232714891],
[194284.985381794,691284.232714891]
]);
var polygon2 = L.polygon([
[194284.985381796, 776624.232714881],
[ 194284.985381797, 792074.232714881],
[183034.985381797, 792074.232714881],
[183034.985381796, 776624.232714881],
[194284.985381796, 776624.232714881]
]);
var polygon3 = L.polygon([
[194284.985381796, 760999.232714881],
[ 194284.985381796, 776561.732714881],
[183034.985381796, 776561.732714881],
[183034.985381796, 760999.232714881],
[194284.985381796, 760999.232714881]
]);
var polygon4 = L.polygon([
[194284.985381796, 760936.732714881],
[183034.985381796, 760936.732714881],
[183034.985381796, 746524.232714881],
[194284.985381796, 746524.232714881],
[194284.985381796, 760936.732714881]
]);
var polygon5 = L.polygon([
[221659.985381796, 746430.48271488],
[221659.985381796, 787730.482714881],
[210409.985381797, 787730.482714881],
[210409.985381796, 746430.482714881],
[221659.985381796, 746430.48271488]
]);  
var polygon6 = L.polygon([
[221659.985381794, 672190.48271489],
[221659.985381794, 714527.982714867],
[210409.985381795, 714527.982714867],
[210409.985381794, 672190.48271489],
[221659.985381794, 672190.48271489]
]); 
var polygon7 = L.polygon([
[194284.985381794, 699096.732714891],
[194284.985381794, 713396.732714867],
[183034.985381795, 713396.732714867],
[183034.985381794, 699096.732714891],
[194284.985381794, 699096.732714891]
]);  
var polygon8 = L.polygon([
[194284.985381794, 667846.732714891],
[194284.985381794, 690996.732714867],
[183034.985381794, 690996.732714867],
[183034.985381794, 667846.732714891],
[194284.985381794, 667846.732714891]
]); 
var polygon9 = L.polygon([
[237784.985381796, 776736.732714857],
[249034.985381796,776736.732714857],
[249034.985381796 ,792074.23271488],
[237784.985381796, 792074.23271488],
[237784.985381796, 776736.732714857]
]); 
var polygon10 = L.polygon([
[237784.985381796, 761111.732714857],
[249034.985381796, 761111.732714857],
[249034.985381796, 776449.23271488],
[237784.985381796, 776449.23271488],
[237784.985381796, 761111.732714857]
]); 
var polygon11 = L.polygon([
[237784.985381796, 760824.23271488],
[237784.985381796, 746524.23271488],
[249034.985381796, 746524.23271488],
[249034.985381796, 760824.23271488],
[237784.985381796, 760824.23271488]
]);
var polygon12 = L.polygon([
[194655.330234443, 722601.833567863],
[194655.330234443, 732293.223039016],
[184655.330234443, 732293.223039016],
[184655.33023444, 722601.833567863],
[194655.330234443, 722601.833567863]
]); 
var polygon13 = L.polygon([
[194655.330234443, 732580.723039016],
[194655.330234443, 737314.333567863],
[184655.330234443, 737314.333567863],
[184655.33023444, 732580.723039016],
[194655.330234443, 732580.723039016]
]);

//Create blue circle marker
var blueCircleMarker = L.circle([194284.985381794, 691284.232714891], 5000, {
    color: 'blue',
});
        

//Add red circle marker to one layer
oneLayer.addLayer(polygon1);
oneLayer.addLayer(polygon2);
oneLayer.addLayer(polygon3);
oneLayer.addLayer(polygon4);
oneLayer.addLayer(polygon5);
oneLayer.addLayer(polygon6);
oneLayer.addLayer(polygon7);
oneLayer.addLayer(polygon8);
oneLayer.addLayer(polygon9);
oneLayer.addLayer(polygon10);
oneLayer.addLayer(polygon11);
oneLayer.addLayer(polygon12);
oneLayer.addLayer(polygon13);
        
//oneLayer.bringToFront();
polygon1.bindPopup("D103");
polygon2.bindPopup("A102");
polygon3.bindPopup("A103");
polygon4.bindPopup("A104");
polygon5.bindPopup("B101");
polygon6.bindPopup("E101");
polygon7.bindPopup("D101");        
polygon8.bindPopup("D104");
polygon9.bindPopup("C102");
polygon10.bindPopup("C103");
polygon11.bindPopup("C104"); 
polygon12.bindPopup("Extra1");
polygon13.bindPopup("Extra2");

//Add blue circle marker to two layer
//twoLayer.addLayer(blueCircleMarker);

//On click bring one layer to front
map.on('click', function(){
oneLayer.bringToFront();
});
//On dblclick bring two layer to front
map.on('dblclick', function(){
twoLayer.bringToFront();
});
        

var popup = L.popup();

function onMapClick(e) {

popup
.setLatLng(e.latlng)
.setContent("You clicked the map at " + e.latlng.toString())
.openOn(map);
}

map.on('click', onMapClick);


        
        
        
        
        
var option = function () {
    var tr = $("#track option:selected").val();
    var pc = $("#category option:selected").val();
    var id = $("#mac option:selected").val();
    console.log(id);
    
    if(tr == "People" && pc == "All" && id == "All"){
        enableButton2();
        findallpeople();
        
    }
    else if(tr == undefined || tr == "--Asset/People--"  || pc == undefined || pc == "--Category--" || id == undefined || id == "--ID--"){
        alert("Please Select the Required Fields");
    }
    else if(tr == "Asset" && pc == "All" && id == "All"){
        enableButton2();
        findallassets();
    }
    else if(tr != undefined && tr != "--Asset/People--"  && pc != undefined && pc != "--Category--" && id != undefined && id != "--ID--" && pc != "All" && tr == "People"){
        enableButton2();
        findonepc();
    }
    else if(tr != undefined && tr != "--Asset/People--"  && pc != undefined && pc != "--Category--" && id != undefined && id != "--ID--" && pc != "All" && tr == "Asset"){
        enableButton2();
        findonepca();
    }
    //else if(tr != undefined && tr != "--Asset/People--"  && pc != undefined && pc != "--Category--" && id != undefined && id != "--ID--" && pc != "All" && id == "All" && tr == "People"){
        
        //    findonepc();
          //  }



};
        
        

  <?php
        
        
        
        
        
if(isset($_POST['count2'])){
$url = "http://172.17.137.160:3333/count2";
#echo $url;
$m->room=$_POST['room6'];
$m->met=$_POST['meters3'];
$m->pc=$_POST['person_category16'];
$m->t1=$_POST['t1'];
$m->t2=$_POST['t2'];
$feilds= json_encode($m);
#echo $feilds;
//url-ify the data for the POST
//open connection
$ch = curl_init($url);

//set the url, number of POST vars, POST data

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($ch, CURLOPT_POSTFIELDS, $feilds);                                                                  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
'Content-Type: application/json',                                                                                
'Content-Length: ' . strlen($feilds))                                                                       
);                  
//execute post
$result = curl_exec($ch);
echo $result;
$result=json_decode($result,true);
echo "check";
print_r($result);  
echo "</script>";
echo "<script>";

for($i=0;$i<sizeof($result);$i++)
{
#echo " alert(".$result[$i]['dist'].");\n"; 
$d = $result[$i]['count'];
//$d1 = $d/1248.134 ;
//$dt = number_format((float)$d1, 2, '.', '');
echo " alert('".$d."'+' Persons');\n"; 
//echo " alert(".$meter1.");\n"; 

}
echo "</script>";
echo "<script>";

//close connection
curl_close($ch);
#echo "window.location.loadmap()";
echo "window.location = 'people_live.php'";
    echo "\n findallpeople();";
}

        
if(isset($_POST['count1'])){
$url = "http://172.17.137.160:3333/count1";
#echo $url;
$m->room=$_POST['room5'];
$m->pc=$_POST['person_category15'];
$m->t1=$_POST['t1'];
$m->t2=$_POST['t2'];
//$m->mac2=$_POST['mac3'];
$feilds= json_encode($m);
#echo $feilds;
//url-ify the data for the POST
//open connection
$ch = curl_init($url);

//set the url, number of POST vars, POST data

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($ch, CURLOPT_POSTFIELDS, $feilds);                                                                  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
'Content-Type: application/json',                                                                                
'Content-Length: ' . strlen($feilds))                                                                       
);                  
//execute post
$result = curl_exec($ch);
echo $result;
$result=json_decode($result,true);
echo "check";
print_r($result);  
echo "</script>";
echo "<script>";

for($i=0;$i<sizeof($result);$i++)
{
#echo " alert(".$result[$i]['dist'].");\n"; 
$d = $result[$i]['count'];
//$d1 = $d/1248.134 ;
//$dt = number_format((float)$d1, 2, '.', '');
echo " alert('".$d."'+' Persons');\n"; 
//echo " alert(".$meter1.");\n"; 

}
echo "</script>";
echo "<script>";

//close connection
curl_close($ch);
#echo "window.location.loadmap()";
echo "window.location = 'people_live.php'";
    echo "\n findallpeople();";
}
        
        
if(isset($_POST['calculated1'])){
$url = "http://172.17.137.160:3333/distpeople1";
#echo $url;
$m->mac1=$_POST['mac2'];
$m->mac2=$_POST['mac3'];
$m->t1=$_POST['t1'];
$m->t2=$_POST['t2'];
$feilds= json_encode($m);
#echo $feilds;
//url-ify the data for the POST
//open connection
$ch = curl_init($url);

//set the url, number of POST vars, POST data

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($ch, CURLOPT_POSTFIELDS, $feilds);                                                                  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
'Content-Type: application/json',                                                                                
'Content-Length: ' . strlen($feilds))                                                                       
);                  
//execute post
$result = curl_exec($ch);
echo $result;
$result=json_decode($result,true);
echo "check";
print_r($result);  
echo "</script>";
echo "<script>";

for($i=0;$i<sizeof($result);$i++)
{
#echo " alert(".$result[$i]['dist'].");\n"; 
$d = $result[$i]['dist'];
$d1 = $d/1248.134 ;
$dt = number_format((float)$d1, 2, '.', '');
echo " alert('".$dt."'+' Meters');\n"; 
//echo " alert(".$meter1.");\n"; 

}
echo "</script>";
echo "<script>";

//close connection
curl_close($ch);
#echo "window.location.loadmap()";
    //echo "\n findallpeople();";
echo "window.location = 'people_live.php'";
    //echo "\n findallpeople();";
}

  
if(isset($_POST['calculated2'])){
$url = "http://172.17.137.160:3333/distpeople2";
#echo $url;
$m->mac=$_POST['mac4'];
$m->room=$_POST['room2'];
$m->t1=$_POST['t1'];
$m->t2=$_POST['t2'];
$feilds= json_encode($m);
#echo $feilds;
//url-ify the data for the POST
//open connection
$ch = curl_init($url);

//set the url, number of POST vars, POST data

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($ch, CURLOPT_POSTFIELDS, $feilds);                                                                  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
'Content-Type: application/json',                                                                                
'Content-Length: ' . strlen($feilds))                                                                       
);                  
//execute post
$result = curl_exec($ch);
echo $result;
$result=json_decode($result,true);
echo "check";
print_r($result);  
echo "</script>";
echo "<script>";

for($i=0;$i<sizeof($result);$i++)
{
#echo " alert(".$result[$i]['dist'].");\n"; 

$c = $result[$i]['dist'];
$c1 = $c/1248.134 ;
$ct = number_format((float)$c1, 2, '.', '');
echo " alert('".$ct."'+' Meters');\n"; 


}
echo "</script>";
echo "<script>";

//close connection
curl_close($ch);
#echo "window.location.loadmap()";
echo "window.location = 'people_live.php'";
}       


if(isset($_POST['Locate2'])){
$url = "http://172.17.137.160:3333/occupied";
#echo $url;
$m->c=$_POST['crowd'];
$m->t1=$_POST['t1'];
$m->t2=$_POST['t2'];           
$feilds= json_encode($m);
#echo $feilds;
//url-ify the data for the POST
//open connection
$ch = curl_init($url);

//set the url, number of POST vars, POST data

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($ch, CURLOPT_POSTFIELDS, $feilds);                                                                  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
'Content-Type: application/json',                                                                                
'Content-Length: ' . strlen($feilds))                                                                       
);                  
//execute post
$result = curl_exec($ch);
#echo $result;
$result=json_decode($result,true);

//echo "check".$result;

for($i=0;$i<sizeof($result);$i++)
{
$r = $result[$i]['p'];

// echo " alert(".$r.");\n";  
//echo "check".$r;

$a = str_replace("MULTIPOLYGON","","$r");
//echo $a;

$b = str_replace(",","],[","$a");
//echo $b;

$c = str_replace(" ",",","$b");
//echo $c;

$d = str_replace("(((","[[","$c");
//echo $d;

$e = str_replace(")))","]]","$d");
echo $e;

echo "\n L.polygon(".$e." ,{ color: 'red', fillColor: '#e03', fillOpacity: 1 }).addTo(map);\n";

//echo "\n L.marker([".$result[$i]['x'].",".$result[$i]['y']."]).addTo(map);\n"; 
//echo "loadmap()";         

}



//close connection
curl_close($ch);
#echo "window.location.loadmap()";
//echo "window.location = 'livequery.php'";

}


if(isset($_POST['LocateRoom'])){
$url = "http://172.17.137.160:3333/room1";
#echo $url;
$m->c=$_POST['roomr'];
$m->t1=$_POST['t1'];
$m->t2=$_POST['t2'];          
$feilds= json_encode($m);
#echo $feilds;
//url-ify the data for the POST
//open connection
$ch = curl_init($url);

//set the url, number of POST vars, POST data

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($ch, CURLOPT_POSTFIELDS, $feilds);                                                                  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
'Content-Type: application/json',                                                                                
'Content-Length: ' . strlen($feilds))                                                                       
);                  
//execute post
$result = curl_exec($ch);
#echo $result;
$result=json_decode($result,true);

//echo "check".$result;

for($i=0;$i<sizeof($result);$i++)
{
$r = $result[$i]['p'];

// echo " alert(".$r.");\n";  
//echo "check".$r;

$a = str_replace("MULTIPOLYGON","","$r");
//echo $a;

$b = str_replace(",","],[","$a");
//echo $b;

$c = str_replace(" ",",","$b");
//echo $c;

$d = str_replace("(((","[[","$c");
//echo $d;

$e = str_replace(")))","]]","$d");
echo $e;

echo "\n L.polygon(".$e." ,{ color: 'red', fillColor: '#e03', fillOpacity: 1 }).addTo(map);\n";

//echo "\n L.marker([".$result[$i]['x'].",".$result[$i]['y']."]).addTo(map);\n"; 
//echo "loadmap()";         

}



//close connection
curl_close($ch);
#echo "window.location.loadmap()";
//echo "window.location = 'livequery.php'";

}

       
if(isset($_POST['calculateda1'])){
$url = "http://172.17.137.160:3333/distpeople1a";
#echo $url;
$m->epc1=$_POST['epc2'];
$m->epc2=$_POST['epc3'];
$m->t1=$_POST['t1'];
$m->t2=$_POST['t2'];
$feilds= json_encode($m);
#echo $feilds;
//url-ify the data for the POST
//open connection
$ch = curl_init($url);

//set the url, number of POST vars, POST data

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($ch, CURLOPT_POSTFIELDS, $feilds);                                                                  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
'Content-Type: application/json',                                                                                
'Content-Length: ' . strlen($feilds))                                                                       
);                  
//execute post
$result = curl_exec($ch);
echo $result;
$result=json_decode($result,true);
echo "check";
print_r($result);  
echo "</script>";
echo "<script>";

for($i=0;$i<sizeof($result);$i++)
{
#echo " alert(".$result[$i]['dist'].");\n"; 
$d = $result[$i]['dist'];
$d1 = $d/1248.134 ;
$dt = number_format((float)$d1, 2, '.', '');
echo " alert('".$dt."'+' Meters');\n"; 
//echo " alert(".$meter1.");\n"; 

}
echo "</script>";
echo "<script>";

//close connection
curl_close($ch);
#echo "window.location.loadmap()";
echo "window.location = 'people_live.php'";
    echo "\n findallpeople();";
}
        

if(isset($_POST['calculateda2'])){
$url = "http://172.17.137.160:3333/distpeople2a";
#echo $url;
$m->epc=$_POST['epc4'];
$m->room=$_POST['roomA2'];
$m->t1=$_POST['t1'];
$m->t2=$_POST['t2'];
$feilds= json_encode($m);
#echo $feilds;
//url-ify the data for the POST
//open connection
$ch = curl_init($url);

//set the url, number of POST vars, POST data

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($ch, CURLOPT_POSTFIELDS, $feilds);                                                                  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
'Content-Type: application/json',                                                                                
'Content-Length: ' . strlen($feilds))                                                                       
);                  
//execute post
$result = curl_exec($ch);
echo $result;
$result=json_decode($result,true);
echo "check";
print_r($result);  
echo "</script>";
echo "<script>";

for($i=0;$i<sizeof($result);$i++)
{
#echo " alert(".$result[$i]['dist'].");\n"; 

$c = $result[$i]['dist'];
$c1 = $c/1248.134 ;
$ct = number_format((float)$c1, 2, '.', '');
echo " alert('".$ct."'+' Meters');\n"; 


}
echo "</script>";
echo "<script>";

//close connection
curl_close($ch);
#echo "window.location.loadmap()";
echo "window.location = 'people_live.php'";
}  
        
if(isset($_POST['counta2'])){
$url = "http://172.17.137.160:3333/count2a";
#echo $url;
$m->room=$_POST['roomA6'];
$m->met=$_POST['metersa3'];
$m->pc=$_POST['asset_category16'];
$m->t1=$_POST['t1'];
$m->t2=$_POST['t2'];
$feilds= json_encode($m);
#echo $feilds;
//url-ify the data for the POST
//open connection
$ch = curl_init($url);

//set the url, number of POST vars, POST data

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($ch, CURLOPT_POSTFIELDS, $feilds);                                                                  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
'Content-Type: application/json',                                                                                
'Content-Length: ' . strlen($feilds))                                                                       
);                  
//execute post
$result = curl_exec($ch);
echo $result;
$result=json_decode($result,true);
echo "check";
print_r($result);  
echo "</script>";
echo "<script>";

for($i=0;$i<sizeof($result);$i++)
{
#echo " alert(".$result[$i]['dist'].");\n"; 
$d = $result[$i]['count'];
//$d1 = $d/1248.134 ;
//$dt = number_format((float)$d1, 2, '.', '');
echo " alert('".$d."'+' Assets');\n"; 
//echo " alert(".$meter1.");\n"; 

}
echo "</script>";
echo "<script>";

//close connection
curl_close($ch);
#echo "window.location.loadmap()";
echo "window.location = 'people_live.php'";
    echo "\n findallpeople();";
}

        
if(isset($_POST['counta1'])){
$url = "http://172.17.137.160:3333/count1a";
#echo $url;
$m->room=$_POST['roomA5'];
$m->pc=$_POST['asset_category15'];
$m->t1=$_POST['t1'];
$m->t2=$_POST['t2'];
//$m->mac2=$_POST['mac3'];
$feilds= json_encode($m);
#echo $feilds;
//url-ify the data for the POST
//open connection
$ch = curl_init($url);

//set the url, number of POST vars, POST data

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
curl_setopt($ch, CURLOPT_POSTFIELDS, $feilds);                                                                  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
'Content-Type: application/json',                                                                                
'Content-Length: ' . strlen($feilds))                                                                       
);                  
//execute post
$result = curl_exec($ch);
echo $result;
$result=json_decode($result,true);
echo "check";
print_r($result);  
echo "</script>";
echo "<script>";

for($i=0;$i<sizeof($result);$i++)
{
#echo " alert(".$result[$i]['dist'].");\n"; 
$d = $result[$i]['count'];
//$d1 = $d/1248.134 ;
//$dt = number_format((float)$d1, 2, '.', '');
echo " alert('".$d."'+' Assets');\n"; 
//echo " alert(".$meter1.");\n"; 

}
echo "</script>";
echo "<script>";

//close connection
curl_close($ch);
#echo "window.location.loadmap()";
echo "window.location = 'people_live.php'";
    echo "\n findallpeople();";
}
        
?>        


        
        
        
        


</script>

           
</body>

</html>