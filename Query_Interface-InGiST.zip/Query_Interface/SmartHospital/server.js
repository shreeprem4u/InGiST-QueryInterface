var util = require('util');
var http = require('http');
const fs = require('fs');
var express = require('express');
var bodyParser = require('body-parser');


var path = require('path');

var pg = require('pg');
//var connectionString = 'postgres://postgres:amuda2017@172.17.9.61:5432/smartbuilding'; //host:port/dbname
var connectionString = 'postgres://amudalab3:amudalab@127.0.0.1:5432/smartbuilding'; //host:port/dbname
var client = new pg.Client(connectionString);
client.connect();

var app = express();
var server = http.Server(app);

app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json({
    limit: '50mb',
    parameterLimit: 10000000000000
}));

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/people_live.php'));
});

app.get('/people', function (req, res) {
    res.sendFile(path.join(__dirname + '/people_live.php'));
});

//To Load the Amuda Lab shape file
app.get('/amuda1/:floorid', function (req, res) {
    "use strict";
    //////console.log('floor route');
    fs.readdir('./amuda' + req.params.floorid + '/', (err, files) => {
        let fileList = [];
        if (req.params.floorid) {
            files.forEach(file => {
                fileList.push('/amuda' + req.params.floorid + '/' + file);
            });
            res.json({
                files: fileList
            });
        } else {
            res.json({
                files: []
            });
        }
    });
});


//to load the floor map of ab3
app.get('/floor/:floorid', function (req, res) {
    "use strict";
    ////console.log('floor route');
    fs.readdir('./floor' + req.params.floorid + '/', (err, files) => {
        let fileList = [];
        if (req.params.floorid) {
            files.forEach(file => {
                fileList.push('/floor' + req.params.floorid + '/' + file);
            });
            res.json({
                files: fileList
            });
        } else {
            res.json({
                files: []
            });
        }
    });
});


//to list the mac id's in dropdown list
app.get('/mac/:pc', function (req, res) {
    var results = [];
    var pc1 = req.params.pc;
    //to load id's i the dropdown list
    //var query = client.query("select DISTINCT person_id from  person_details where person_category = $1",[pc1]);
    var query = client.query("SELECT coalesce(name, '') || ', '|| coalesce(department, '') as mac from person_details where person_category = $1",[pc1]);
    query.on('row', (row) => {
        results.push(row);
    });
    query.on('end', () => {
        return res.json(results);
    });
});


//to list the epc id's in dropdown list
app.get('/epc/:ac', function (req, res) {
    var results = [];
    var pc1 = req.params.ac;
    ////console.log("hi");
    
   var query = client.query("select distinct name as epc from asset_details where asset_category = $1" ,[pc1]);
    query.on('row', (row) => {
        results.push(row);
    });
    query.on('end', () => {
        return res.json(results);
    });
});


//emergency app visualization
app.get('/emergency', function (req, res) {
    var results = [];
    var query = client.query("SELECT type,center_of_circle_x as x ,center_of_circle_y as y,radius as r FROM emergency_app WHERE time = (SELECT MAX(time) FROM main_person t2 WHERE t1.mac = t2.mac)");
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
        res.end(JSON.stringify(results));
    });

});


//to list the personcategory in dropdown list
app.get('/person_category', function (req, res) {
    var results = [];
    var query = client.query("select distinct person_category from person_details");
    query.on('row', (row) => {
        results.push(row);
    });
    query.on('end', () => {
        return res.json(results);
    });
});

//to list the asset category in dropdown list
app.get('/asset_category', function (req, res) {
    var results = [];
    ////console.log("hi");
    var query = client.query("select distinct asset_category from asset_details");
    query.on('row', (row) => {
        results.push(row);
    });
    query.on('end', () => {
        return res.json(results);
    });
});

//to list the roomid in dropdown list
app.get('/roomid', function (req, res) {
    var results = [];
    var query = client.query("select room_name from room where floor_id = 1 order by room_name ");
    query.on('row', (row) => {
        results.push(row);
    });
    query.on('end', () => {
        return res.json(results);
    });
});

//to track all people/assets
app.get('/live/:pc', function (req, res) {
"use strict";
////console.log('floor route');
var results = [];
var m1 = req.params.pc;
var r1 = m1.split(',');
var m = r1[0];
var time1 = r1[1];
var time2 = r1[2];
////console.log(time1);
if(m == "Asset"){

    if(time1 =="" && time2 ==""){
var query = client.query("SELECT distinct on (t1.epc) asset_category as person_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2, room r WHERE t1.epc in (select epc from asset_details where t1.epc=t2.epc) and time between (NOW()::timestamp(0) - interval '40 second') and (NOW()::timestamp(0) + interval '40 second') and ST_Contains(r.geom,t1.geom)");
query.on('row', (row) => {
results.push(row);
});
query.on('end', () => {
res.end(JSON.stringify(results));
});
}
else if(time1 !="" && time2 ==""){
var query = client.query("SELECT distinct on (t1.epc) asset_category as person_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2, room r WHERE t1.epc in (select epc from asset_details where t1.epc=t2.epc) and time = $1 and ST_Contains(r.geom,t1.geom)",[time1]);
query.on('row', (row) => {
results.push(row);
});
query.on('end', () => {
res.end(JSON.stringify(results));
});

}
else if(time1 =="" && time2 !=""){
var query = client.query("SELECT distinct on (t1.epc) asset_category as person_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2, room r WHERE t1.epc in (select epc from asset_details where t1.epc=t2.epc) and time = $1 and ST_Contains(r.geom,t1.geom)",[time2]);
query.on('row', (row) => {
results.push(row);
});
query.on('end', () => {
res.end(JSON.stringify(results));
});

}
else if(time1 !="" && time2 !=""){
var query = client.query("SELECT distinct on (t1.epc) asset_category as person_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2, room r WHERE t1.epc in (select epc from asset_details where t1.epc=t2.epc) and time between $1 and $2 and ST_Contains(r.geom,t1.geom)",[time1,time2]);
query.on('row', (row) => {
results.push(row);
});
query.on('end', () => {
res.end(JSON.stringify(results));
});

}
    
    


}
    
else if(m == "People"){
if(time1 =="" && time2 ==""){
var query = client.query("SELECT distinct on (mac) person_category,t2.name as mac,time,x,y,r.room_name FROM main_person t1,person_details t2, room r WHERE t1.mac in (select mac from person_details where t1.mac=t2.mac) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and ST_Contains(r.geom,t1.geom)");
query.on('row', (row) => {
results.push(row);
});
query.on('end', () => {
res.end(JSON.stringify(results));
});
}
else if(time1 !="" && time2 ==""){
var query = client.query("SELECT distinct on (mac) person_category,t2.name as mac,time,x,y,r.room_name  FROM main_person t1,person_details t2, room r WHERE t1.mac in (select mac from person_details where t1.mac=t2.mac) and time = $1 and ST_Contains(r.geom,t1.geom)",[time1]);
query.on('row', (row) => {
results.push(row);
});
query.on('end', () => {
res.end(JSON.stringify(results));
});

}
else if(time1 =="" && time2 !=""){
var query = client.query("SELECT distinct on (mac) person_category,t2.name as mac,time,x,y,r.room_name  FROM main_person t1,person_details t2, room r WHERE t1.mac in (select mac from person_details where t1.mac=t2.mac) and time = $1 and ST_Contains(r.geom,t1.geom)",[time2]);
query.on('row', (row) => {
results.push(row);
});
query.on('end', () => {
res.end(JSON.stringify(results));
});

}
else if(time1 !="" && time2 !=""){
var query = client.query("SELECT distinct on (mac) person_category,t2.name as mac,time,x,y,r.room_name  FROM main_person t1,person_details t2, room r WHERE t1.mac in (select mac from person_details where t1.mac=t2.mac) and time between $1 and $2 and ST_Contains(r.geom,t1.geom)",[time1,time2]);
query.on('row', (row) => {
results.push(row);
});
query.on('end', () => {
res.end(JSON.stringify(results));
});

}

}


});

//to display the location of people based on category
app.get('/findl/:mac', function (req, res) {
    "use strict";
    ////console.log('floor route');
    var results = [];
    var m1 = req.params.mac;
    var r1 = m1.split(',');
    var m = r1[0];
    var pc = r1[1];
    var time1 = r1[2];
    var time2 = r1[3];
   // //console.log("check"+time1);
   // //console.log("check"+time2);
   /// //console.log("check"+m);
   // //console.log("checkpc"+pc);
    
    if(m == "All")
    {
    if(time1 =="" && time2 ==""){
    var query = client.query("SELECT distinct on (mac) person_category,t2.name as mac,time,x,y,r.room_name FROM main_person t1,person_details t2, room r WHERE t1.mac in (select mac from person_details where t1.mac=t2.mac and person_category = $1) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')and ST_Contains(r.geom,t1.geom)", [pc]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 !="" && time2 ==""){
    var query = client.query("SELECT distinct on (mac) person_category,t2.name as mac,time,x,y,r.room_name FROM main_person t1,person_details t2, room r WHERE t1.mac in (select mac from person_details where t1.mac=t2.mac and person_category = $1) and time = $2 and ST_Contains(r.geom,t1.geom) ", [pc,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 =="" && time2 !=""){
    var query = client.query("SELECT distinct on (mac) person_category,t2.name as mac,time,x,y,r.room_name FROM main_person t1,person_details t2, room r WHERE t1.mac in (select mac from person_details where t1.mac=t2.mac and person_category = $1) and time = $2 and ST_Contains(r.geom,t1.geom)", [pc,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 !=""){
    var query = client.query("SELECT distinct on (mac) person_category,t2.name as mac,time,x,y,r.room_name FROM main_person t1,person_details t2, room r WHERE t1.mac in (select mac from person_details where t1.mac=t2.mac and person_category = $1) and time between $2 and $3 and ST_Contains(r.geom,t1.geom)", [pc,time1, time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }

    }
    else{
    if(time1 =="" && time2 ==""){
    var query = client.query("SELECT distinct on (mac) person_category,t2.name as mac,time,x,y,r.room_name FROM main_person t1,person_details t2, room r WHERE t1.mac in (select mac from person_details where t1.mac=t2.mac) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and t2.name = $1 and ST_Contains(r.geom,t1.geom)", [m]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 !="" && time2 ==""){
    var query = client.query("SELECT distinct on (mac) person_category,name as mac,time,x,y,r.room_name FROM main_person t1,person_details t2, room r WHERE t1.mac in (select mac from person_details where t1.mac=t2.mac) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')  and t2.name = $1 and time = $2  and ST_Contains(r.geom,t1.geom)", [m,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 =="" && time2 !=""){
    var query = client.query("SELECT distinct on (mac) person_category,name as mac,time,x,y,r.room_name FROM main_person t1,person_details t2, room r WHERE t1.mac in (select mac from person_details where t1.mac=t2.mac) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')  and t2.name = $1 and time = $2  and ST_Contains(r.geom,t1.geom)", [m,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 !=""){
    var query = client.query("SELECT distinct on (mac) person_category,name as mac,time,x,y,r.room_name FROM main_person t1,person_details t2, room r WHERE t1.mac in (select mac from person_details where t1.mac=t2.mac) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')  and t2.name = $1 and time between $2 and $3  and ST_Contains(r.geom,t1.geom)", [m,time1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    }
    
    
});


//to display the location of assets based on category
app.get('/finda/:mac', function (req, res) {
    "use strict";
    ////console.log('floor route');
    var results = [];
    var m1 = req.params.mac;
    var r1 = m1.split(',');
    var m = r1[0];
    var pc = r1[1];
    var time1 = r1[2];
    var time2 = r1[3];
    //console.log("check"+time1);
    //console.log("check"+time2);
    //console.log("check"+m);
    //console.log("checkpc"+pc);
    
     if(m == "All")
    {
    if(time1 =="" && time2 ==""){
    var query = client.query("SELECT distinct on (t1.epc) asset_category as person_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2, room r WHERE t1.epc in (select epc from asset_details where t1.epc=t2.epc and asset_category = $1) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and ST_Contains(r.geom,t1.geom)", [pc]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 !="" && time2 ==""){
    var query = client.query("SELECT distinct on (t1.epc) asset_category as person_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2, room r WHERE t1.epc in (select epc from asset_details where t1.epc=t2.epc and asset_category = $1) and time = $2  and ST_Contains(r.geom,t1.geom)c ", [pc,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 =="" && time2 !=""){
    var query = client.query("SELECT distinct on (t1.epc) asset_category as person_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2, room r WHERE t1.epc in (select epc from asset_details where t1.epc=t2.epc and asset_category = $1) and time = $2  and ST_Contains(r.geom,t1.geom)", [pc,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 !=""){
    var query = client.query("SELECT distinct on (t1.epc) asset_category as person_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2, room r WHERE t1.epc in (select epc from asset_details where t1.epc=t2.epc and asset_category = $1) and time between $2 and $3  and ST_Contains(r.geom,t1.geom)", [pc,time1, time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }

    }
    else{
    if(time1 =="" && time2 ==""){
    var query = client.query("SELECT distinct on (t1.epc) asset_category as person_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2, room r WHERE t1.epc in (select epc from asset_details where t1.epc=t2.epc) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and t2.name = $1  and ST_Contains(r.geom,t1.geom)", [m]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 !="" && time2 ==""){
    var query = client.query("SELECT distinct on (t1.epc) asset_category as person_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2, room r WHERE t1.epc in (select epc from asset_details where t1.epc=t2.epc) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')  and t2.name = $1 and time = $2  and ST_Contains(r.geom,t1.geom)", [m,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 =="" && time2 !=""){
    var query = client.query("SELECT distinct on (t1.epc) asset_category as person_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2, room r WHERE t1.epc in (select epc from asset_details where t1.epc=t2.epc) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')  and t2.name = $1 and time = $2 order by t1.epc", [m,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 !=""){
    var query = client.query("SELECT distinct on (t1.epc) asset_category as person_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2, room r WHERE t1.epc in (select epc from asset_details where t1.epc=t2.epc) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')  and t2.name = $1 and time between $2 and $3 order by t1.epc", [m,time1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    }

});


//to display the location of all people in room
app.get('/findr/:room1', function (req, res) {
    "use strict";
    ////console.log('floor route');
    var results = [];
    var r = req.params.room1;
    var r1 = r.split(',');
    var pc = r1[0];
    var r = r1[1];
    var time1 = r1[2];
    var time2 = r1[3];
    //var m = req.params.person_category2;
    ////console.log(r);
    ////console.log(pc);
    
    if(time1 =="" && time2 ==""){
    var query = client.query("SELECT distinct on (t2.mac) person_category,t2.name as mac,time,x,y,r.room_name FROM main_person t1,person_details t2,room r WHERE t1.mac in(select mac from person_details where person_category = $1) and ST_Contains((select geom from room where room_name = $2),t1.geom)  AND person_category = $3 and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')  and ST_Contains(r.geom,t1.geom) AND t1.mac = t2.mac",[pc,r,pc]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 !="" && time2 ==""){
    var query = client.query("SELECT distinct on (t2.mac) person_category,t2.name as mac,time,x,y,r.room_name FROM main_person t1,person_details t2,room r WHERE t1.mac in(select mac from person_details where person_category = $1) and ST_Contains((select geom from room where room_name = $2),t1.geom)  AND person_category = $3 and time = $4 and ST_Contains(r.geom,t1.geom) AND t1.mac = t2.mac",[pc,r,pc,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 =="" && time2 !=""){
    var query = client.query("SELECT distinct on (t2.mac) person_category,t2.name as mac,time,x,y,r.room_name FROM main_person t1,person_details t2,room r WHERE t1.mac in(select mac from person_details where person_category = $1) and ST_Contains((select geom from room where room_name = $2),t1.geom)  AND person_category = $3 and time = $4 and ST_Contains(r.geom,t1.geom) AND t1.mac = t2.mac",[pc,r,pc,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 !=""){
    var query = client.query("SELECT distinct on (t2.mac) person_category,t2.name as mac,time,x,y,r.room_name FROM main_person t1,person_details t2,room r WHERE t1.mac in(select mac from person_details where person_category = $1) and ST_Contains((select geom from room where room_name = $2),t1.geom)  AND person_category = $3 and time between $4 and $5 and ST_Contains(r.geom,t1.geom) AND t1.mac = t2.mac",[pc,r,pc,time1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    
});


//to display the location of all assets in room
app.get('/findra/:room1', function (req, res) {
    "use strict";
    var results = [];
    var r = req.params.room1;
    var r1 = r.split(',');
    var pc = r1[0];
    var r = r1[1];
    var time1 = r1[2];
    var time2 = r1[3];
   // //console.log(pc);

    
        if(time1 =="" && time2 ==""){
    var query = client.query("SELECT distinct on (t2.epc) asset_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2,room r WHERE t1.epc in(select epc from asset_details where asset_category = $1) and ST_Contains((select geom from room where room_name = $2 ),t1.geom)  AND asset_category = $3 and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')  and ST_Contains(r.geom,t1.geom) AND t1.epc = t2.epc",[pc,r,pc]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 !="" && time2 ==""){
    var query = client.query("SELECT distinct on (t2.epc) asset_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2,room r WHERE t1.epc in(select epc from asset_details where asset_category = $1) and ST_Contains((select geom from room where room_name = $2 ),t1.geom)  AND asset_category = $3 and time = $4  and ST_Contains(r.geom,t1.geom) AND t1.epc = t2.epc",[pc,r,pc,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 =="" && time2 !=""){
    var query = client.query("SELECT distinct on (t2.epc) asset_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2,room r WHERE t1.epc in(select epc from asset_details where asset_category = $1) and ST_Contains((select geom from room where room_name = $2 ),t1.geom)  AND asset_category = $3 and time = $4  and ST_Contains(r.geom,t1.geom) AND t1.epc = t2.epc",[pc,r,pc,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 !=""){
    var query = client.query("SELECT distinct on (t2.epc) asset_category,t2.name as mac,time,x,y,r.room_name FROM main_asset t1,asset_details t2,room r WHERE t1.epc in(select epc from asset_details where asset_category = $1) and ST_Contains((select geom from room where room_name = $2 ),t1.geom)  AND asset_category = $3 and time between $4 and $5 and ST_Contains(r.geom,t1.geom) AND t1.epc = t2.epc",[pc,r,pc,time1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }

});

//to display the location of k people to a person
app.get('/findk/:mac6', function (req, res) {
    "use strict";
    ////console.log('floor route');
    var results = [];
    var r = req.params.mac6;
    var r1 = r.split(',');
    var m = r1[0];
    var k = parseInt(r1[1]);
    var pc = r1[2];
    var time1 = r1[3];
    var time2 = r1[4];
    ////console.log(r);
    ////console.log(m);
    ////console.log(k);
    ////console.log(pc);
    
        if(time1 =="" && time2 ==""){
 var query = client.query("select x1,y1,x,y,mac,mac1,person_category,room_name,dist from(SELECT DISTINCT on (p2.mac) t.person_category,t.name as mac,t1.name as mac1,r.room_name,ST_Distance(p1.geom, p2.geom) as dist, p1.x as x1, p1.y as y1, p2.x as x, p2.y as y FROM main_person As p1, main_person As p2,person_details t,person_details t1,room r WHERE p2.mac in (select mac from person_details where t.person_category = $1) and p1.mac in (select mac from person_details where name = $2) and p1.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and p2.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and t1.name = (select name from person_details where mac in (select mac from person_details where name = $3)) and ST_Contains(r.geom,p2.geom) and p1<>p2 and p2.mac = t.mac and p2.mac in (select mac from person_details where name <> $5) )a ORDER BY dist limit $4", [pc,m,m,k,m]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 !="" && time2 ==""){
    var query = client.query("select x1,y1,x,y,mac,mac1,person_category,room_name,dist from(SELECT DISTINCT on (p2.mac) t.person_category,t.name as mac,t1.name as mac1,r.room_name,ST_Distance(p1.geom, p2.geom) as dist, p1.x as x1, p1.y as y1, p2.x as x, p2.y as y FROM main_person As p1, main_person As p2,person_details t,person_details t1,room r WHERE p2.mac in (select mac from person_details where t.person_category = $1) and p1.mac in (select mac from person_details where name = $2) and p1.time = $4 and p2.time = $5 and t1.name = (select name from person_details where mac in (select mac from person_details where name = $3)) and ST_Contains(r.geom,p2.geom) and p1<>p2 and p2.mac = t.mac and p2.mac in (select mac from person_details where name <> $6) )a ORDER BY dist limit $7",[pc,m,m,time1,time1,m,k]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 =="" && time2 !=""){
    var query = client.query("select x1,y1,x,y,mac,mac1,person_category,room_name,dist from(SELECT DISTINCT on (p2.mac) t.person_category,t.name as mac,t1.name as mac1,r.room_name,ST_Distance(p1.geom, p2.geom) as dist, p1.x as x1, p1.y as y1, p2.x as x, p2.y as y FROM main_person As p1, main_person As p2,person_details t,person_details t1,room r WHERE p2.mac in (select mac from person_details where t.person_category = $1) and p1.mac in (select mac from person_details where name = $2) and p1.time = $4 and p2.time = $5 and t1.name = (select name from person_details where mac in (select mac from person_details where name = $3)) and ST_Contains(r.geom,p2.geom) and p1<>p2 and p2.mac = t.mac and p2.mac in (select mac from person_details where name <> $6) )a ORDER BY dist limit $7",[pc,m,m,time2,time2,m,k]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 !=""){
    var query = client.query("select x1,y1,x,y,mac,mac1,person_category,room_name,dist from(SELECT DISTINCT on (p2.mac) t.person_category,t.name as mac,t1.name as mac1,r.room_name,ST_Distance(p1.geom, p2.geom) as dist, p1.x as x1, p1.y as y1, p2.x as x, p2.y as y FROM main_person As p1, main_person As p2,person_details t,person_details t1,room r WHERE p2.mac in (select mac from person_details where t.person_category = $1) and p1.mac in (select mac from person_details where name = $2) and p1.time between $4 and $5 and p2.time between $6 and $7 and t1.name = (select name from person_details where mac in (select mac from person_details where name = $3)) and ST_Contains(r.geom,p2.geom) and p1<>p2 and p2.mac = t.mac and p2.mac in (select mac from person_details where name <> $8) )a ORDER BY dist limit $9",[pc,m,m,time1,,time2,time1,time2,m,k]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    
   

});


//to display the location of k asset to an asset
app.get('/findka/:mac6', function (req, res) {
    "use strict";
    ////console.log('floor route');
    var results = [];
    var r = req.params.mac6;
    var r1 = r.split(',');
    var m = r1[0];
    var k = parseInt(r1[1]);
   var pc = r1[2];
    var time1 = r1[3];
    var time2 = r1[4];
    //console.log(r);
    ////console.log(m);
    ////console.log(k);
    ////console.log(pc);
    
        if(time1 =="" && time2 ==""){
 var query = client.query("select x1,y1,x,y,mac,mac1,asset_category,room_name,dist from(SELECT DISTINCT on (p2.epc) t.asset_category,t.name as mac,t1.name as mac1,r.room_name,ST_Distance(p1.geom, p2.geom) as dist, p1.x as x1, p1.y as y1, p2.x as x, p2.y as y FROM main_asset As p1, main_asset As p2,asset_details t,asset_details t1,room r WHERE p2.epc in (select epc from asset_details where t.asset_category = $1) and p1.epc in (select epc from asset_details where name = $2) and p1.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and p2.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and t1.name = (select name from asset_details where epc in (select epc from asset_details where name = $3)) and ST_Contains(r.geom,p2.geom) and p1<>p2 and p2.epc = t.epc and p2.epc in (select epc from asset_details where name <> $4) )a ORDER BY dist limit $5", [pc,m,m,m,k]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 !="" && time2 ==""){
    var query = client.query("select x1,y1,x,y,mac,mac1,asset_category,room_name,dist from(SELECT DISTINCT on (p2.epc) t.asset_category,t.name as mac,t1.name as mac1,r.room_name,ST_Distance(p1.geom, p2.geom) as dist, p1.x as x1, p1.y as y1, p2.x as x, p2.y as y FROM main_asset As p1, main_asset As p2,asset_details t,asset_details t1,room r WHERE p2.epc in (select epc from asset_details where t.asset_category = $1) and p1.epc in (select epc from asset_details where name = $2) and p1.time = $6 and p2.time = $7 and t1.name = (select name from asset_details where epc in (select epc from asset_details where name = $3)) and ST_Contains(r.geom,p2.geom) and p1<>p2 and p2.epc = t.epc and p2.epc in (select epc from asset_details where name <> $4) )a ORDER BY dist limit $5",[pc,m,m,m,k,time1,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 =="" && time2 !=""){
    var query = client.query("select x1,y1,x,y,mac,mac1,asset_category,room_name,dist from(SELECT DISTINCT on (p2.epc) t.asset_category,t.name as mac,t1.name as mac1,r.room_name,ST_Distance(p1.geom, p2.geom) as dist, p1.x as x1, p1.y as y1, p2.x as x, p2.y as y FROM main_asset As p1, main_asset As p2,asset_details t,asset_details t1,room r WHERE p2.epc in (select epc from asset_details where t.asset_category = $1) and p1.epc in (select epc from asset_details where name = $2) and p1.time = $6 and p2.time = $7 and t1.name = (select name from asset_details where epc in (select epc from asset_details where name = $3)) and ST_Contains(r.geom,p2.geom) and p1<>p2 and p2.epc = t.epc and p2.epc in (select epc from asset_details where name <> $4) )a ORDER BY dist limit $5",[pc,m,m,m,k,time2,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 !=""){
    var query = client.query("select x1,y1,x,y,mac,mac1,asset_category,room_name,dist from(SELECT DISTINCT on (p2.epc) t.asset_category,t.name as mac,t1.name as mac1,r.room_name,ST_Distance(p1.geom, p2.geom) as dist, p1.x as x1, p1.y as y1, p2.x as x, p2.y as y FROM main_asset As p1, main_asset As p2,asset_details t,asset_details t1,room r WHERE p2.epc in (select epc from asset_details where t.asset_category = $1) and p1.epc in (select epc from asset_details where name = $2) and p1.time between $6 and $7 and p2.time between $8 and $9 and t1.name = (select name from asset_details where epc in (select epc from asset_details where name = $3)) and ST_Contains(r.geom,p2.geom) and p1<>p2 and p2.epc = t.epc and p2.epc in (select epc from asset_details where name <> $4) )a ORDER BY dist limit $5",[pc,m,m,time1,time2,time1,time2,m,k]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }

});


//to display the location of k people to a room 
app.get('/findk1/:mac', function (req, res) {
    "use strict";
    ////console.log('floor route');
    var results = [];
    var r = req.params.mac;
    var r1 = r.split(',');
    var m = r1[0];
    var k = parseInt(r1[1]);
    var pc = r1[2];
    var time1 = r1[3];
    var time2 = r1[4];
    ////console.log(r);
    ////console.log(m);
    ////console.log(k);
    ////console.log(pc);
    if(time1 =="" && time2 ==""){
  var query = client.query("select x,y,mac,room_name,dist,person_category from(SELECT DISTINCT on (p2.mac) t.person_category,t.name as mac,r.room_name, p2.x as x, p2.y as y,ST_Distance(p2.geom, r.geom) as dist FROM main_person As p2,person_details t,room r WHERE p2.mac in (select mac from person_details where t.person_category = $1) and r.room_name= $2 and p2.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')  and p2.mac = t.mac)a ORDER BY dist  limit $3", [pc,m,k]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
        res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 ==""){
    var query = client.query("select x,y,mac,room_name,dist,person_category from(SELECT DISTINCT on (p2.mac) t.person_category,t.name as mac,r.room_name, p2.x as x, p2.y as y,ST_Distance(p2.geom, r.geom) as dist FROM main_person As p2,person_details t,room r WHERE p2.mac in (select mac from person_details where t.person_category = $1) and r.room_name= $2 and p2.time = $4 and p2.mac = t.mac)a ORDER BY dist  limit $3",[pc,m,k,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 =="" && time2 !=""){
    var query = client.query("select x,y,mac,room_name,dist,person_category from(SELECT DISTINCT on (p2.mac) t.person_category,t.name as mac,r.room_name, p2.x as x, p2.y as y,ST_Distance(p2.geom, r.geom) as dist FROM main_person As p2,person_details t,room r WHERE p2.mac in (select mac from person_details where t.person_category = $1) and r.room_name= $2 and p2.time = $4 and p2.mac = t.mac)a ORDER BY dist  limit $3",[pc,m,k,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 !=""){
    var query = client.query("select x,y,mac,room_name,dist,person_category from(SELECT DISTINCT on (p2.mac) t.person_category,t.name as mac,r.room_name, p2.x as x, p2.y as y,ST_Distance(p2.geom, r.geom) as dist FROM main_person As p2,person_details t,room r WHERE p2.mac in (select mac from person_details where t.person_category = $1) and r.room_name= $2 and p2.time between $4 and $5 and p2.mac = t.mac)a ORDER BY dist  limit $3",[pc,m,k,time1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    
    
   
});

//to display the location of k assets to a room
app.get('/findk1a/:mac', function (req, res) {
    "use strict";
    ////console.log('floor route');
    var results = [];
var r = req.params.mac;
    var r1 = r.split(',');
    var m = r1[0];
    var k = parseInt(r1[1]);
    var pc = r1[2];
    var time1 = r1[3];
    var time2 = r1[4];
    ////console.log(r);
    ////console.log(m);
    ////console.log(k);
    ////console.log(pc);
    if(time1 =="" && time2 ==""){
  var query = client.query("select x,y,mac,room_name,dist,asset_category from(SELECT DISTINCT on (p2.epc) t.asset_category,t.name as mac,r.room_name, p2.x as x, p2.y as y,ST_Distance(p2.geom, r.geom) as dist FROM main_asset As p2,asset_details t,room r WHERE p2.epc in (select epc from asset_details where t.asset_category = $1) and r.room_name= $2 and p2.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')  and p2.epc = t.epc)a ORDER BY dist  limit $3", [pc,m,k]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
        res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 ==""){
    var query = client.query("select x,y,mac,room_name,dist,asset_category from(SELECT DISTINCT on (p2.epc) t.asset_category,t.name as mac,r.room_name, p2.x as x, p2.y as y,ST_Distance(p2.geom, r.geom) as dist FROM main_asset As p2,asset_details t,room r WHERE p2.epc in (select epc from asset_details where t.asset_category = $1) and r.room_name= $2 and p2.time = $4  and p2.epc = t.epc)a ORDER BY dist  limit $3",[pc,m,k,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 =="" && time2 !=""){
    var query = client.query("select x,y,mac,room_name,dist,asset_category from(SELECT DISTINCT on (p2.epc) t.asset_category,t.name as mac,r.room_name, p2.x as x, p2.y as y,ST_Distance(p2.geom, r.geom) as dist FROM main_asset As p2,asset_details t,room r WHERE p2.epc in (select epc from asset_details where t.asset_category = $1) and r.room_name= $2 and p2.time = $4   and p2.epc = t.epc)a ORDER BY dist  limit $3",[pc,m,k,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 !=""){
    var query = client.query("select x,y,mac,room_name,dist,asset_category from(SELECT DISTINCT on (p2.epc) t.asset_category,t.name as mac,r.room_name, p2.x as x, p2.y as y,ST_Distance(p2.geom, r.geom) as dist FROM main_asset As p2,asset_details t,room r WHERE p2.epc in (select epc from asset_details where t.asset_category = $1) and r.room_name= $2 and p2.time between $4 and $5 and p2.epc = t.epc)a ORDER BY dist  limit $3",[pc,m,k,time1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }

});


//to display the location of people within m meters to a person
app.get('/findm/:meter', function (req, res) {
    "use strict";
    ////console.log('floor route');
    var results = [];
    var r = req.params.meter;
    var r1 = r.split(',');
    var m = r1[0];
    var k = parseInt(r1[1]);
    var pc = r1[2]
    var meters = k * 1248.134;
    var time1 = r1[3];
    var time2 = r1[4];
    ////console.log(r);
    ////console.log(m);
    ////console.log(meters);
    ////console.log(pc);
        if(time1 =="" && time2 ==""){
       var query = client.query("SELECT  distinct on (p2.mac) t2.name as mac1,t1.name as mac,  p2.x as x, p2.y as y, p1.x as x1, p1.y as y1, r.room_name FROM main_person As p1, main_person As p2,person_details t2, person_details t1, room r WHERE p2.mac in (select mac from person_details where p1.mac=t2.mac and person_category = $1) and p1.mac in (select mac from person_details where name = $2) AND ST_DWithin(p1.geom, p2.geom,$3) and p1.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and p2.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and ST_Contains(r.geom,p2.geom) and t1.mac = p2.mac and p2.mac in (select mac from person_details where name <> $4) ", [pc, m, meters,m]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
        res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 ==""){
   var query = client.query("SELECT  distinct on (p2.mac) t2.name as mac1,t1.name as mac,  p2.x as x, p2.y as y, p1.x as x1, p1.y as y1, r.room_name FROM main_person As p1, main_person As p2,person_details t2, person_details t1, room r WHERE p2.mac in (select mac from person_details where p1.mac=t2.mac and person_category = $1) and p1.mac in (select mac from person_details where name = $2) AND ST_DWithin(p1.geom, p2.geom,$3) and p1.time = $4 and p2.time = $5 and ST_Contains(r.geom,p2.geom) and t1.mac = p2.mac and p2.mac in (select mac from person_details where name <> $6)",[pc, m, meters,time1,time1,m]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 =="" && time2 !=""){
   var query = client.query("SELECT  distinct on (p2.mac) t2.name as mac1,t1.name as mac,  p2.x as x, p2.y as y, p1.x as x1, p1.y as y1, r.room_name FROM main_person As p1, main_person As p2,person_details t2, person_details t1, room r WHERE p2.mac in (select mac from person_details where p1.mac=t2.mac and person_category = $1) and p1.mac in (select mac from person_details where name = $2) AND ST_DWithin(p1.geom, p2.geom,$3) and p1.time = $4 and p2.time = $5 and ST_Contains(r.geom,p2.geom) and t1.mac = p2.mac and p2.mac in (select mac from person_details where name <> $6)",[pc, m, meters,time2,time2,m]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 !=""){
   var query = client.query("SELECT  distinct on (p2.mac) t2.name as mac1,t1.name as mac,  p2.x as x, p2.y as y, p1.x as x1, p1.y as y1, r.room_name FROM main_person As p1, main_person As p2,person_details t2, person_details t1, room r WHERE p2.mac in (select mac from person_details where p1.mac=t2.mac and person_category = $1) and p1.mac in (select mac from person_details where name = $2) AND ST_DWithin(p1.geom, p2.geom,$3) and p1.time between $4 and $5 and p2.time between $6 and $7 and ST_Contains(r.geom,p2.geom) and t1.mac = p2.mac and p2.mac in (select mac from person_details where name <> $8)",[pc, m, meters,time1,time2,time1,time2,m]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    
    
   

});


//to display the location of assets within m meters to an asset
app.get('/findma/:meter', function (req, res) {
    "use strict";
    ////console.log('floor route');
    var results = [];
    var r = req.params.meter;
    var r1 = r.split(',');
    var m = r1[0];
    var k = parseInt(r1[1]);
    var pc = r1[2];
    var meters = k * 1248.134;

     var time1 = r1[3];
    var time2 = r1[4];
    //console.log(r);
    //console.log(m);
    //console.log(meters);
    //console.log(pc);
    
        if(time1 =="" && time2 ==""){
       var query = client.query("SELECT  distinct on (p2.epc) t2.name as mac1,t1.name as mac, t1.asset_category, p2.x as x, p2.y as y, p1.x as x1, p1.y as y1, r.room_name FROM main_asset As p1, main_asset As p2,asset_details t2, asset_details t1, room r WHERE p2.epc in (select epc from asset_details where p1.epc=t2.epc and asset_category = $1) and p1.epc in (select epc from asset_details where name = $2) AND ST_DWithin(p1.geom, p2.geom,$3) and p1.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and p2.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and ST_Contains(r.geom,p2.geom) and t1.epc = p2.epc AND p2.epc in (select epc from asset_details where name <> $4)", [pc, m, meters,m]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
        res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 ==""){
   var query = client.query("SELECT  distinct on (p2.epc) t2.name as mac1,t1.name as mac,  p2.x as x, p2.y as y, p1.x as x1, p1.y as y1, r.room_name FROM main_asset As p1, main_asset As p2,asset_details t2, asset_details t1, room r WHERE p2.epc in (select epc from asset_details where p1.epc=t2.epc and asset_category = $1) and p1.epc in (select epc from asset_details where name = $2) AND ST_DWithin(p1.geom, p2.geom,$3) and p1.time = $4 and p2.time = $5 and ST_Contains(r.geom,p2.geom) and t1.epc = p2.epc AND p2.epc in (select epc from asset_details where name <> $6)",[pc, m, meters,time1,time1,m]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 =="" && time2 !=""){
   var query = client.query("SELECT  distinct on (p2.epc) t2.name as mac1,t1.name as mac,  p2.x as x, p2.y as y, p1.x as x1, p1.y as y1, r.room_name FROM main_asset As p1, main_asset As p2,asset_details t2, asset_details t1, room r WHERE p2.epc in (select epc from asset_details where p1.epc=t2.epc and asset_category = $1) and p1.epc in (select epc from asset_details where name = $2) AND ST_DWithin(p1.geom, p2.geom,$3) and p1.time = $4 and p2.time = $5 and ST_Contains(r.geom,p2.geom) and t1.epc = p2.epc AND p2.epc in (select epc from asset_details where name <> $6)",[pc, m, meters,time2,time2,m]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 !=""){
   var query = client.query("SELECT  distinct on (p2.epc) t2.name as mac1,t1.name as mac,  p2.x as x, p2.y as y, p1.x as x1, p1.y as y1, r.room_name FROM main_asset As p1, main_asset As p2,asset_details t2, asset_details t1, room r WHERE p2.epc in (select epc from asset_details where p1.epc=t2.epc and asset_category = $1) and p1.epc in (select epc from asset_details where name = $2) AND ST_DWithin(p1.geom, p2.geom,$3) and p1.time between $4 and $5 and p2.time between $6 and $7 and ST_Contains(r.geom,p2.geom) and t1.epc = p2.epc AND p2.epc in (select epc from asset_details where name <> $8)",[pc, m, meters,time1,time2,time1,time2,m]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    

});


//to display the location of people within m meters to a room
app.get('/findm1/:meter', function (req, res) {
    "use strict";
    ////console.log('floor route');
    var results = [];
    var r = req.params.meter;
    var r1 = r.split(',');
    var m = r1[0];
    var k = parseInt(r1[1]);
    var pc = r1[2];
    var meters = k * 1248.134;
    var time1 = r1[3];
    var time2 = r1[4];
    ////console.log(r);
  //  //console.log(m);
    ////console.log(meters);
    ////console.log(pc);

    
            if(time1 =="" && time2 ==""){
      var query = client.query("SELECT distinct on (p2.mac) t2.name as mac, r.room_name, p2.x as x, p2.y as y FROM room As p1, main_person As p2, room as r,person_details t2 WHERE p2.mac in (select mac from person_details  where  p2.mac=t2.mac and person_category = $1) and p1.room_name = $2 AND ST_DWithin(p2.geom, p1.geom,$3) and p2.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and ST_Contains(r.geom,p2.geom)", [pc,m, meters]);

    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
        res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 ==""){
      var query = client.query("SELECT distinct on (p2.mac) t2.name as mac, r.room_name, p2.x as x, p2.y as y FROM room As p1, main_person As p2, room as r,person_details t2 WHERE p2.mac in (select mac from person_details  where  p2.mac=t2.mac and person_category = $1) and p1.room_name = $2 AND ST_DWithin(p2.geom, p1.geom,$3) and ST_Contains(r.geom,p2.geom) and p2.time = $4", [pc,m, meters,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 =="" && time2 !=""){
      var query = client.query("SELECT distinct on (p2.mac) t2.name as mac, r.room_name, p2.x as x, p2.y as y FROM room As p1, main_person As p2, room as r,person_details t2 WHERE p2.mac in (select mac from person_details  where  p2.mac=t2.mac and person_category = $1) and p1.room_name = $2 AND ST_DWithin(p2.geom, p1.geom,$3) and ST_Contains(r.geom,p2.geom) and p2.time = $4", [pc,m, meters,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 !=""){
      var query = client.query("SELECT distinct on (p2.mac) t2.name as mac, r.room_name, p2.x as x, p2.y as y FROM room As p1, main_person As p2, room as r,person_details t2 WHERE p2.mac in (select mac from person_details  where  p2.mac=t2.mac and person_category = $1) and p1.room_name = $2 AND ST_DWithin(p2.geom, p1.geom,$3) and ST_Contains(r.geom,p2.geom) and p2.time between $4 and $5", [pc,m, meters,time1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    

});


//to display the location of assets within m meters to a room
app.get('/findm1a/:meter', function (req, res) {
    "use strict";
    ////console.log('floor route');
    var results = [];
    var r = req.params.meter;
    var r1 = r.split(',');
    var m = r1[0];
    var k = parseInt(r1[1]);
    var meters = k * 1248.134;
     var pc = r1[2];
    var time1 = r1[3];
    var time2 = r1[4];

                if(time1 =="" && time2 ==""){
      var query = client.query("SELECT distinct on (p2.epc) t2.name as mac, r.room_name, p2.x as x, p2.y as y FROM room As p1, main_asset As p2, room as r,asset_details t2 WHERE p2.epc in (select epc from asset_details  where  p2.epc=t2.epc and asset_category = $1) and p1.room_name = $2 AND ST_DWithin(p2.geom, p1.geom,$3) and p2.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and ST_Contains(r.geom,p2.geom)", [pc,m, meters]);

    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
        res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 ==""){
      var query = client.query("SELECT distinct on (p2.epc) t2.name as mac, r.room_name, p2.x as x, p2.y as y FROM room As p1, main_asset As p2, room as r,asset_details t2 WHERE p2.epc in (select epc from asset_details  where  p2.epc=t2.epc and asset_category = $1) and p1.room_name = $2 AND ST_DWithin(p2.geom, p1.geom,$3) and p2.time = $4 and ST_Contains(r.geom,p2.geom)", [pc,m, meters,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 =="" && time2 !=""){
      var query = client.query("SELECT distinct on (p2.epc) t2.name as mac, r.room_name, p2.x as x, p2.y as y FROM room As p1, main_asset As p2, room as r,asset_details t2 WHERE p2.epc in (select epc from asset_details  where  p2.epc=t2.epc and asset_category = $1) and p1.room_name = $2 AND ST_DWithin(p2.geom, p1.geom,$3) and p2.time = $4 and ST_Contains(r.geom,p2.geom)", [pc,m, meters,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !="" && time2 !=""){
      var query = client.query("SELECT distinct on (p2.epc) t2.name as mac, r.room_name, p2.x as x, p2.y as y FROM room As p1, main_asset As p2, room as r,asset_details t2 WHERE p2.epc in (select epc from asset_details  where  p2.epc=t2.epc and asset_category = $1) and p1.room_name = $2 AND ST_DWithin(p2.geom, p1.geom,$3) and p2.time between $4 and $5 and ST_Contains(r.geom,p2.geom)", [pc,m, meters,time1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    

});


//to find the most occupied location (people)
app.post('/occupied', function (req, res) {
    var results = [];
    var crowd = req.body['c'];
    ////console.log(crowd);
  
        if(crowd == "Most"){
        
        var query = client.query("SELECT ST_AsText(geom) as p from (select geom from ((select r.room_id,r.geom, count(DISTINCT mac) as c from main_person as t, room as r where ST_Contains(r.geom,t.geom) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') group by room_id,r.geom))a where a.c = (select max(c) from (select r.room_id, count(DISTINCT mac) as c from main_person as t, room as r where r.room_name <> 'Floor1 Base' and ST_Contains(r.geom,t.geom) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') group by room_id)x))v");
            
        query.on('row', (row) => {
            
            results.push(row);
        });
        query.on('end', () => {
            res.end(JSON.stringify(results));
        });
        
}
    
    else if(crowd == "Least")
        {
        var query = client.query("SELECT ST_AsText(geom) as p from (select geom from ((select r.room_id,r.geom, count(DISTINCT mac) as c from main_person as t, room as r where ST_Contains(r.geom,t.geom) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') group by room_id,r.geom))a where a.c = (select min(c) from (select r.room_id, count(DISTINCT mac) as c from main_person as t, room as r where  r.room_name <> 'Floor1 Base' and ST_Contains(r.geom,t.geom) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') group by room_id)x))v");
           
        query.on('row', (row) => {
            results.push(row);
        });
        query.on('end', () => {
            res.end(JSON.stringify(results));
        });
                         }
        });


//to find the most occupied location (asset)
app.post('/occupieda', function (req, res) {
    var results = [];
    var crowd = req.body['c'];
    ////console.log(crowd);
  
        if(crowd == "Most"){
            var query = client.query("SELECT ST_AsText(geom) as p from (select geom from ((select r.room_id,r.geom, count(DISTINCT epc) as c from main_asset as t, room as r where ST_Contains(r.geom,t.geom) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') group by room_id,r.geom))a where a.c = (select max(c) from (select r.room_id, count(DISTINCT epc) as c from main_asset as t, room as r where r.room_name <> 'Floor1 Base' and ST_Contains(r.geom,t.geom) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') group by room_id)x))v");
            
        query.on('row', (row) => {
            
            results.push(row);
        });
        query.on('end', () => {
            res.end(JSON.stringify(results));
        });
        
}
    
    else if(crowd == "Least")
        {
            var query = client.query("SELECT ST_AsText(geom) as p from (select geom from ((select r.room_id,r.geom, count(DISTINCT epc) as c from main_asset as t, room as r where ST_Contains(r.geom,t.geom) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') group by room_id,r.geom))a where a.c = (select min(c) from (select r.room_id, count(DISTINCT epc) as c from main_asset as t, room as r where r.room_name <> 'Floor1 Base' and ST_Contains(r.geom,t.geom) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') group by room_id)x))v");
           
        query.on('row', (row) => {
            results.push(row);
        });
        query.on('end', () => {
            res.end(JSON.stringify(results));
        });
                         }
        });


app.post('/room1', function (req, res) {
    var results = [];
    var crowd = req.body['c'];
    //var crowd = req.params.crowd;
    ////console.log(crowd);
             //var query = client.query("SELECT ST_AsText(geom) as p from room where room_id = 1010032");
            var query = client.query("SELECT ST_AsText(geom) as p from room where room_name = $1",[crowd]);
        query.on('row', (row) => {
            results.push(row);
        });
        query.on('end', () => {
            res.end(JSON.stringify(results));
        });

        });


app.post('/room1a', function (req, res) {
    var results = [];
    var crowd = req.body['c'];
    //var crowd = req.params.crowd;
    ////console.log(crowd);
             //var query = client.query("SELECT ST_AsText(geom) as p from room where room_id = 1010032");
            var query = client.query("SELECT ST_AsText(geom) as p from room where room_name = $1",[crowd]);
        query.on('row', (row) => {
            results.push(row);
        });
        query.on('end', () => {
            res.end(JSON.stringify(results));
        });

        });


//to calculate the distance between two persons 
app.post('/distpeople1', function (req, res) {
    var results = [];
    var m1a = req.body['mac1'];
    var m2a = req.body['mac2'];
    var r1 = m1a.split(',');
    var m1 = r1[0];
        var r2 = m2a.split(',');
    var m2 = r2[0];
    var time1 = req.body['t1'];
    var time2 = req.body['t2'];
    //console.log('inputmac' + time1);
    //console.log('inputmac' + time2);

    if(time1 == null && time2 == null){
        var query = client.query("SELECT distinct on (p1.mac) p1.mac,p2.mac, ST_Distance(p1.geom, p2.geom) as dist FROM main_person p1, main_person p2 WHERE p1.mac in (select mac from person_details where name = $1) AND p2.mac in (select mac from person_details where name = $2) and p1.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and p2.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')", [m1, m2]);
        query.on('row', (row) => {
            results.push(row);
        });
        query.on('end', () => {
            res.end(JSON.stringify(results));
        });
    }
    else if(time1 != null && time2 ==null){
        var query = client.query("SELECT distinct on (p1.mac) p1.mac,p2.mac, ST_Distance(p1.geom, p2.geom) as dist FROM main_person p1, main_person p2 WHERE p1.mac in (select mac from person_details where name = $1) AND p2.mac in (select mac from person_details where name = $2) and p1.time = $3 and p2.time = $4",[m1, m2,time1,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 ==null && time2 !=null){
        var query = client.query("SELECT distinct on (p1.mac) p1.mac,p2.mac, ST_Distance(p1.geom, p2.geom) as dist FROM main_person p1, main_person p2 WHERE p1.mac in (select mac from person_details where name = $1) AND p2.mac in (select mac from person_details where name = $2) and p1.time = $3 and p2.time = $4",[m1, m2,time2,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !=null && time2 !=null){
        var query = client.query("SELECT distinct on (p1.mac) p1.mac,p2.mac, ST_Distance(p1.geom, p2.geom) as dist FROM main_person p1, main_person p2 WHERE p1.mac in (select mac from person_details where name = $1) AND p2.mac in (select mac from person_details where name = $2) and p1.time between $3 and $4 and p2.time between $5 and $6",[m1, m2,time1,time2,time1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
});


//to calculate the distance between two assets
app.post('/distpeople1a', function (req, res) {
    var results = [];
    var m1 = req.body['epc1'];
    var m2 = req.body['epc2'];
    ////console.log('inputmac' + m1);
    ////console.log('inputmac' + m2);
        
    
    var time1 = req.body['t1'];
    var time2 = req.body['t2'];
    //console.log('inputmac' + time1);
    //console.log('inputmac' + time2);

    if(time1 == null && time2 == null){
       var query = client.query("SELECT distinct on (p1.epc) p1.epc,p2.epc, ST_Distance(p1.geom, p2.geom) as dist FROM main_asset p1, main_asset p2 WHERE p1.epc in (select epc from asset_details where name = $1) AND p2.epc in (select epc from asset_details where name = $2) and p1.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') and p2.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')", [m1, m2]);
        query.on('row', (row) => {
            results.push(row);
        });
        query.on('end', () => {
            res.end(JSON.stringify(results));
        });
    }
    else if(time1 != null && time2 ==null){
    var query = client.query("SELECT distinct on (p1.epc) p1.epc,p2.epc, ST_Distance(p1.geom, p2.geom) as dist FROM main_asset p1, main_asset p2 WHERE p1.epc in (select epc from asset_details where name = $1) AND p2.epc in (select epc from asset_details where name = $2)and p1.time = $3 and p2.time = $4",[m1, m2,time1,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 ==null && time2 !=null){
    var query = client.query("SELECT distinct on (p1.epc) p1.epc,p2.epc, ST_Distance(p1.geom, p2.geom) as dist FROM main_asset p1, main_asset p2 WHERE p1.epc in (select epc from asset_details where name = $1) AND p2.epc in (select epc from asset_details where name = $2) and p1.time = $3 and p2.time = $4",[m1, m2,time2,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !=null && time2 !=null){
    var query = client.query("SELECT distinct on (p1.epc) p1.epc,p2.epc, ST_Distance(p1.geom, p2.geom) as dist FROM main_asset p1, main_asset p2 WHERE p1.epc in (select epc from asset_details where name = $1) AND p2.epc in (select epc from asset_details where name = $2) and p1.time between $3 and $4 and p2.time between $5 and $6",[m1, m2,time1,time2,time1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    
    
});

  
//to calculate the distance between a person and a room
app.post('/distpeople2', function (req, res) {
    var results = [];
    var ma = req.body['mac'];
    var r = req.body['room'];
        var r1 = ma.split(',');
    var m = r1[0];

  //  //console.log('inputmac' + m);
  //  //console.log('inputmac' + r);
    var time1 = req.body['t1'];
    var time2 = req.body['t2'];
    
    ////console.log('inputmac' + time1);
    ////console.log('inputmac' + time2);

    if(time1 == null && time2 == null){
        
    var query = client.query("SELECT distinct on (p1.mac) ST_Distance(p1.geom, p2.geom) as dist FROM main_person p1, room p2  WHERE p1.mac in (select mac from person_details where name = $1) AND p2.room_name =$2 and p1.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') ", [m, r]);
        query.on('row', (row) => {
            results.push(row);
        });
        query.on('end', () => {
            res.end(JSON.stringify(results));
        });
    }
    else if(time1 != null && time2 ==null){
    var query = client.query("SELECT distinct on (p1.mac) ST_Distance(p1.geom, p2.geom) as dist FROM main_person p1, room p2  WHERE p1.mac in (select mac from person_details where name = $1) AND p2.room_name =$2 and p1.time =$3 ",[m,r,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 ==null && time2 !=null){
    var query = client.query("SELECT distinct on (p1.mac) ST_Distance(p1.geom, p2.geom) as dist FROM main_person p1, room p2  WHERE p1.mac in (select mac from person_details where name = $1) AND p2.room_name =$2 and p1.time =$3 ",[m,r,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !=null && time2 !=null){
    var query = client.query("SELECT distinct on (p1.mac) ST_Distance(p1.geom, p2.geom) as dist FROM main_person p1, room p2  WHERE p1.mac in (select mac from person_details where name = $1) AND p2.room_name =$2 and p1.time between $3 and $4",[m,r,time1, time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    
    
    });


//to calculate the distance between an asset and a room 
app.post('/distpeople2a', function (req, res) {
    var results = [];
    var m = req.body['epc'];
    var r = req.body['room'];
    ////console.log('inputmac' + m);
     ////console.log('room' + r);

     var time1 = req.body['t1'];
    var time2 = req.body['t2'];
    //console.log('inputmac' + time1);
    //console.log('inputmac' + time2);

    if(time1 == null && time2 == null){
        
    var query = client.query("SELECT distinct on (p1.epc) ST_Distance(p1.geom, p2.geom) as dist FROM main_asset p1, room p2  WHERE p1.epc in (select epc from asset_details where name = $1) AND p2.room_name =$2 and p1.time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second') ", [m, r]);
        query.on('row', (row) => {
            results.push(row);
        });
        query.on('end', () => {
            res.end(JSON.stringify(results));
        });
    }
    else if(time1 != null && time2 ==null){
    var query = client.query("SELECT distinct on (p1.epc) ST_Distance(p1.geom, p2.geom) as dist FROM main_asset p1, room p2  WHERE p1.epc in (select epc from asset_details where name = $1) AND p2.room_name =$2  and p1.time =$3 ",[m,r,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 ==null && time2 !=null){
    var query = client.query("SELECT distinct on (p1.epc) ST_Distance(p1.geom, p2.geom) as dist FROM main_asset p1, room p2  WHERE p1.epc in (select epc from asset_details where name = $1) AND p2.room_name =$2 and p1.time =$3 ",[m,r,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !=null && time2 !=null){
    var query = client.query("SELECT distinct on (p1.epc) ST_Distance(p1.geom, p2.geom) as dist FROM main_asset p1, room p2  WHERE p1.epc in (select epc from asset_details where name = $1) AND p2.room_name =$2 and p1.time between $3 and $4",[m,r,time1, time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    
    
    });


//to count the persons inside a room
app.post('/count1', function (req, res) {
    var results = [];
    var m1 = req.body['room'];
    var pc = req.body['pc'];
    //var m2 = req.body['mac2'];
    ////console.log('inputmac' + m1);
     var time1 = req.body['t1'];
    var time2 = req.body['t2'];
    //console.log('inputmac' + time1);
    //console.log('inputmac' + time2);

    if(time1 == null && time2 == null){
        
        var query = client.query("SELECT count(DISTINCT mac) as count FROM main_person t1 WHERE mac in (select mac from person_details where person_category = $1) and ST_Contains((select geom from room where room_name = $2),t1.geom) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')", [pc,m1]);
        query.on('row', (row) => {
            results.push(row);
        });
        query.on('end', () => {
            res.end(JSON.stringify(results));
        });
    }
    else if(time1 != null && time2 ==null){
    var query = client.query("SELECT count(DISTINCT mac) as count FROM main_person t1 WHERE mac in (select mac from person_details where person_category = $1) and ST_Contains((select geom from room where room_name = $2),t1.geom) and time =$3 ",[pc,m1,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 ==null && time2 !=null){
    var query = client.query("SELECT count(DISTINCT mac) as count FROM main_person t1 WHERE mac in (select mac from person_details where person_category = $1) and ST_Contains((select geom from room where room_name = $2),t1.geom) and time =$3 ",[pc,m1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !=null && time2 !=null){
    var query = client.query("SELECT count(DISTINCT mac) as count FROM main_person t1 WHERE mac in (select mac from person_details where person_category = $1) and ST_Contains((select geom from room where room_name = $2),t1.geom) and time between $3 and $4 ",[pc,m1,time1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    
    
});


//to count the persons within 'n' meters of a room
app.post('/count2', function (req, res) {
    var results = [];
    var m1 = req.body['room'];
    var m2 = req.body['met'];
    var pc = req.body['pc'];
    var meters = m2 * 1248.134;

    
         var time1 = req.body['t1'];
    var time2 = req.body['t2'];
    //console.log('inputmac' + time1);
    //console.log('inputmac' + time2);

    if(time1 == null && time2 == null){
        
        var query = client.query("SELECT count(DISTINCT p2.mac) as count FROM room As p1, main_person As p2 WHERE mac in (select mac from person_details where person_category = $1) and p1.room_name = $2 AND ST_DWithin(p1.geom, p2.geom,$3) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')", [pc,m1,meters]);
        query.on('row', (row) => {
            results.push(row);
        });
        query.on('end', () => {
            res.end(JSON.stringify(results));
        });
    }
    else if(time1 != null && time2 ==null){
    var query = client.query("SELECT count(DISTINCT p2.mac) as count FROM room As p1, main_person As p2 WHERE mac in (select mac from person_details where person_category = $1) and p1.room_name = $2 AND ST_DWithin(p1.geom, p2.geom,$3) and time = $4",[pc,m1,meters,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 ==null && time2 !=null){
    var query = client.query("SELECT count(DISTINCT p2.mac) as count FROM room As p1, main_person As p2 WHERE mac in (select mac from person_details where person_category = $1) and p1.room_name = $2 AND ST_DWithin(p1.geom, p2.geom,$3) and time = $4",[pc,m1,meters,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !=null && time2 !=null){
    var query = client.query("SELECT count(DISTINCT p2.mac) as count FROM room As p1, main_person As p2 WHERE mac in (select mac from person_details where person_category = $1) and p1.room_name = $2 AND ST_DWithin(p1.geom, p2.geom,$3) and time between $4 and $5",[pc,m1,meters,time1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    
    
});


//to count the assets inside a room
app.post('/count1a', function (req, res) {
    var results = [];
    var m1 = req.body['room'];
    
    
        var pc = req.body['pc'];
     var time1 = req.body['t1'];
    var time2 = req.body['t2'];
    //console.log('inputmac' + time1);
    //console.log('inputmac' + time2);

    if(time1 == null && time2 == null){
        
        var query = client.query("SELECT count(DISTINCT epc) as count FROM main_asset t1 WHERE epc in (select epc from asset_details where asset_category = $1) and ST_Contains((select geom from room where room_name = $2),t1.geom) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')", [pc,m1]);
        query.on('row', (row) => {
            results.push(row);
        });
        query.on('end', () => {
            res.end(JSON.stringify(results));
        });
    }
    else if(time1 != null && time2 ==null){
    var query = client.query("SELECT count(DISTINCT epc) as count FROM main_asset t1 WHERE epc in (select epc from asset_details where asset_category = $1) and ST_Contains((select geom from room where room_name = $2),t1.geom) and time =$3 ",[pc,m1,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 ==null && time2 !=null){
    var query = client.query("SELECT count(DISTINCT mac) as count FROM main_person t1 WHERE mac in (select mac from person_details where person_category = $1) and ST_Contains((select geom from room where room_name = $2),t1.geom) and time =$3 ",[pc,m1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !=null && time2 !=null){
    var query = client.query("SELECT count(DISTINCT mac) as count FROM main_person t1 WHERE mac in (select mac from person_details where person_category = $1) and ST_Contains((select geom from room where room_name = $2),t1.geom) and time between $3 and $4 ",[pc,m1,time1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    
});


//to count the assets within 'n' meters of a room
app.post('/count2a', function (req, res) {
    var results = [];
    var m1 = req.body['room'];
    var m2 = req.body['met'];
    var meters = m2 * 1248.134;
        var pc = req.body['pc'];
    ////console.log('inputmac' + m1);
    ////console.log('inputmac' + m2);
    
             var time1 = req.body['t1'];
    var time2 = req.body['t2'];
   // //console.log('inputmac' + time1);
  //  //console.log('inputmac' + time2);
    
    
if(time1 == null && time2 == null){
        
        var query = client.query("SELECT count(DISTINCT p2.epc) as count FROM room As p1, main_asset As p2 WHERE epc in (select epc from asset_details where asset_category = $1) and p1.room_name = $2 AND ST_DWithin(p1.geom, p2.geom,$3) and time between (NOW()::timestamp(0) - interval '5 second') and (NOW()::timestamp(0) + interval '5 second')", [pc,m1,meters]);
        query.on('row', (row) => {
            results.push(row);
        });
        query.on('end', () => {
            res.end(JSON.stringify(results));
        });
    }
    else if(time1 != null && time2 ==null){
    var query = client.query("SELECT count(DISTINCT p2.epc) as count FROM room As p1, main_asset As p2 WHERE epc in (select epc from asset_details where asset_category = $1) and p1.room_name = $2 AND ST_DWithin(p1.geom, p2.geom,$3) and time = $4",[pc,m1,meters,time1]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });
    }
    else if(time1 ==null && time2 !=null){
    var query = client.query("SELECT count(DISTINCT p2.epc) as count FROM room As p1, main_asset As p2 WHERE epc in (select epc from asset_details where asset_category = $1) and p1.room_name = $2 AND ST_DWithin(p1.geom, p2.geom,$3) and time = $4",[pc,m1,meters,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
    else if(time1 !=null && time2 !=null){
    var query = client.query("SELECT count(DISTINCT p2.epc) as count FROM room As p1, main_asset As p2 WHERE epc in (select epc from asset_details where asset_category = $1) and p1.room_name = $2 AND ST_DWithin(p1.geom, p2.geom,$3) and time between $4 and $5",[pc,m1,meters,time1,time2]);
    query.on('row', (row) => {
    results.push(row);
    });
    query.on('end', () => {
    res.end(JSON.stringify(results));
    });

    }
});


app.listen(3333, "0.0.0.0", function() {
    ////console.log('Listening to port:  ' + 3333);
});


