<html>

<head>
    <title>Introduction</title>
    
    <meta charset="utf-8">
    <meta name="viewport" content-type="width=device-width, initial-scale=0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="combined.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.0.3/dist/leaflet.css" integrity="sha512-07I2e+7D8p6he1SIM+1twR5TIrhUQn9+I6yjqD53JQjFiMf8EtC93ty0/5vJTZGF8aAocvHYNEDJajGdNx1IsQ==" crossorigin="" />
    <link rel="stylesheet" href="http://code.ionicframework.com/ionicons/1.5.2/css/ionicons.min.css">
    <script src="https://unpkg.com/leaflet@1.0.3/dist/leaflet.js" integrity="sha512-A7vV8IFfih/D732iSSKi20u/ooOfj/AGehOKq0f4vLT1Zr2Y+RX7C+w8A1gaSasGtRUZpF/NZgzSAu4/Gc41Lg==" crossorigin=""></script>
    <link rel="stylesheet" href="leaflet.awesome-markers.css">
    <script src="leaflet.awesome-markers.js"></script>
    <script src="js/leaflet-0.7.2/leaflet.ajax.min.js"></script>
   
    <script src="/js/bootstrap-datetimepicker.js"></script>
    <script src="/js/bootstrap.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <link href="/css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
    <script type="text/javascript" src="/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
    <script type="text/javascript" src="/js/locales/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>
    <script src ="/js/leaflet-color-markers.js"></script>
    <link rel="stylesheet" href="/fontawesome/css/font-awesome.min.css">
    <script src = "/server.js"></script>
    <script src = "/function.js"></script>
    
<script src="/js/L.Icon.Pulse.js" ></script>
<link rel="stylesheet" href="/css/L.Icon.Pulse.css" />


    <style>
    .ryt{

   position:fixed;
   right:50px;
   top: 70px;
   
}
        
     
        
    </style>
 
</head>

<body>


<h1 align="center"> <span>E</span>mergency <span>I</span>nterface</h1>

<div style="width:100%;"> <!-- Main Div -->

    <div style="float:left; width:100%;">
                    <select id="fid" onchange="loadmap()" hidden>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
            </select>
        
    </div>
<div style="float:left; width:100%; margin-left:10px;" id = "map">

</div>
</div>
    
    <script>
                
loadmap();

          
function onEachFeature(feature, layer) {
    if (feature.properties) {
        //layer.bindPopup(feature.properties);
    }
}


var map = L.map('map', {
    crs: L.CRS.Simple,
    noWrap: true,
    minZoom: -10000
}).setView([730304, 215616], 13);


function addJSONDataToMap(dataURL) {
    $.getJSON(dataURL, function(jsondata) {
        console.log(jsondata);
        let layer = L.geoJson(jsondata).addTo(map);
        console.log('layer.getBounds() : ');
        console.log(layer.getBounds());
        //boundsArray.push(layer.getBounds());
        map.fitBounds(layer.getBounds());
    });
}


function loadmap() {
    var currentFloor = $("#fid option:selected").val();
    console.log(currentFloor);
    $.getJSON('http://172.17.137.160:3333/floor/' + currentFloor, function(data) {
        console.log(data);
        for (i in data.files) {
            console.log(data.files[i]);
            addJSONDataToMap(data.files[i]);
        }
    });
}
/*
  var circle = L.circle([194190, 698728], {
    color: 'red',
    fillColor: '#f03',
    fillOpacity: 0.5,
    radius: 15000
}).addTo(map);   

L.circleMarker([194190, 698728], {
    color: 'red',
    fillColor: '#f03',
    fillOpacity: 0.5,
    radius: 50,
    animate:'true'
}).addTo(map);      
      
        
    */    
 
var emergency1 = "MEDICAL";
var emergency2 = "MAINTENANCE";
var emergency3 = "SAFETY";
var emergency4 = "FIRE";      
        
var rad = 30;
var x1 = 194190;
var y1 = 698728;
var x2 = 194190;
var y2 = 718728;
var x3 = 204190;
var y3 = 708728;
var x4 = 204190;
var y4 = 728728;
        
if(emergency1 == "MEDICAL")
{
var pulsingIcon1 = L.icon.pulse({iconSize:[rad,rad],color:'red',fillColor: '#FF0000'});
var marker1 = L.marker([x1,y1],{icon: pulsingIcon1}).addTo(map);
               marker1.bindPopup("MEDICAL");
    marker1.addTo(map);
}
if(emergency2 == "MAINTENANCE"){
    var pulsingIcon2 = L.icon.pulse({iconSize:[rad,rad],color:'blue',fillColor: '#0000FF'});
var marker2 = L.marker([x2,y2],{icon: pulsingIcon2});
           marker2.bindPopup("MAINTENANCE");
    marker2.addTo(map);

}
if(emergency3 == "SAFETY"){
    var pulsingIcon3 = L.icon.pulse({iconSize:[rad,rad],color:'yellow',fillColor: '#FFFF00'});
var marker3 = L.marker([x3,y3],{icon: pulsingIcon3});
        marker3.bindPopup("SAFETY");
    marker3.addTo(map);

}
if(emergency4 == "FIRE"){
var pulsingIcon4 = L.icon.pulse({iconSize:[rad,rad],color:'orange',fillColor: ' FFA500'});
var marker4 = L.marker([x4,y4],{icon: pulsingIcon4});
    marker4.bindPopup("FIRE");
    marker4.addTo(map);

}


        
var markers = [];
var totalTrackingObjects = 0;
var emergency = function () {
markers = [];
$.getJSON('http://172.17.137.160:3333/emergency', function (data) {
    totalTrackingObjects = data.length;
    for (var i = 0; i < data.length; i++) {
         var cat = data[i].person_category;
        if(cat == "PATIENT"){
           var colorIcon = colorIcons[1];
            var marker1 = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair', prefix: 'fa', markerColor: 'red'})}).addTo(map);
                markers.push(marker1);
            //icn = 'wheelchair';
            }
        else if(cat == "DOCTOR")
                {
                var colorIcon = colorIcons[3];
                var marker2 = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'user-md', prefix: 'fa', markerColor: 'green'})}).addTo(map);
                markers.push(marker2);
                //icn = 'user-md';
                //icon = 'medkit';
                }
        else{

                        var colorIcon = colorIcons[i % colors.length];
                        console.log(i % colors.length);
                       var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
                markers.push(marker);
        }


    }
});
updateemergency();
};
//
var updateemergency = function () {
$.getJSON('http://172.17.137.160:3333/emergency', function (data) {
    if (data.length == 0) {
        console.log("Detected 0");
        for (var i = 0; i < totalTrackingObjects; i++) {
            map.removeLayer(markers[i]);

            //window.location.reload();
        }
    } else if (data.length != totalTrackingObjects) {
        for (var i = 0; i < totalTrackingObjects; i++) {
            map.removeLayer(markers[i]);
        }
        emergency();
    }
    for (var i = 0; i < data.length; i++) {
        var x = data[i].x;
        var y = data[i].y;
        var mac = data[i].mac;
        var cat = data[i].person_category;
        markers[i].setLatLng([x, y]);
        markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat);
    }
});
};

var findemergency = function () {
setTimeout(function () {
    updateemergencye();
    //clearTimeout(timeout);
    findemergency();

    //loadmap();
}, 10);


};


        
        
        
  
 
var oneLayer = new L.geoJson();
//Add GeoJSON layer to map
map.addLayer(oneLayer);
        
var twoLayer = new L.geoJson();
//Add GeoJSON layer to map
map.addLayer(twoLayer);

//Create polygon
var polygon1 = L.polygon([
[194284.985381794 , 691284.232714891],
[ 194284.985381794,698809.232714867],
[183034.985381794,698809.232714867],
[183034.985381794,691284.232714891],
[194284.985381794,691284.232714891]
]);
var polygon2 = L.polygon([
[194284.985381796, 776624.232714881],
[ 194284.985381797, 792074.232714881],
[183034.985381797, 792074.232714881],
[183034.985381796, 776624.232714881],
[194284.985381796, 776624.232714881]
]);
var polygon3 = L.polygon([
[194284.985381796, 760999.232714881],
[ 194284.985381796, 776561.732714881],
[183034.985381796, 776561.732714881],
[183034.985381796, 760999.232714881],
[194284.985381796, 760999.232714881]
]);
var polygon4 = L.polygon([
[194284.985381796, 760936.732714881],
[183034.985381796, 760936.732714881],
[183034.985381796, 746524.232714881],
[194284.985381796, 746524.232714881],
[194284.985381796, 760936.732714881]
]);
var polygon5 = L.polygon([
[221659.985381796, 746430.48271488],
[221659.985381796, 787730.482714881],
[210409.985381797, 787730.482714881],
[210409.985381796, 746430.482714881],
[221659.985381796, 746430.48271488]
]);  
var polygon6 = L.polygon([
[221659.985381794, 672190.48271489],
[221659.985381794, 714527.982714867],
[210409.985381795, 714527.982714867],
[210409.985381794, 672190.48271489],
[221659.985381794, 672190.48271489]
]); 
var polygon7 = L.polygon([
[194284.985381794, 699096.732714891],
[194284.985381794, 713396.732714867],
[183034.985381795, 713396.732714867],
[183034.985381794, 699096.732714891],
[194284.985381794, 699096.732714891]
]);  
var polygon8 = L.polygon([
[194284.985381794, 667846.732714891],
[194284.985381794, 690996.732714867],
[183034.985381794, 690996.732714867],
[183034.985381794, 667846.732714891],
[194284.985381794, 667846.732714891]
]); 
var polygon9 = L.polygon([
[237784.985381796, 776736.732714857],
[249034.985381796,776736.732714857],
[249034.985381796 ,792074.23271488],
[237784.985381796, 792074.23271488],
[237784.985381796, 776736.732714857]
]); 
var polygon10 = L.polygon([
[237784.985381796, 761111.732714857],
[249034.985381796, 761111.732714857],
[249034.985381796, 776449.23271488],
[237784.985381796, 776449.23271488],
[237784.985381796, 761111.732714857]
]); 
var polygon11 = L.polygon([
[237784.985381796, 760824.23271488],
[237784.985381796, 746524.23271488],
[249034.985381796, 746524.23271488],
[249034.985381796, 760824.23271488],
[237784.985381796, 760824.23271488]
]);
var polygon12 = L.polygon([
[194655.330234443, 722601.833567863],
[194655.330234443, 732293.223039016],
[184655.330234443, 732293.223039016],
[184655.33023444, 722601.833567863],
[194655.330234443, 722601.833567863]
]); 
var polygon13 = L.polygon([
[194655.330234443, 732580.723039016],
[194655.330234443, 737314.333567863],
[184655.330234443, 737314.333567863],
[184655.33023444, 732580.723039016],
[194655.330234443, 732580.723039016]
]);

//Create blue circle marker
var blueCircleMarker = L.circle([194284.985381794, 691284.232714891], 5000, {
    color: 'blue',
});
        

//Add red circle marker to one layer
oneLayer.addLayer(polygon1);
oneLayer.addLayer(polygon2);
oneLayer.addLayer(polygon3);
oneLayer.addLayer(polygon4);
oneLayer.addLayer(polygon5);
oneLayer.addLayer(polygon6);
oneLayer.addLayer(polygon7);
oneLayer.addLayer(polygon8);
oneLayer.addLayer(polygon9);
oneLayer.addLayer(polygon10);
oneLayer.addLayer(polygon11);
oneLayer.addLayer(polygon12);
oneLayer.addLayer(polygon13);
        
//oneLayer.bringToFront();
polygon1.bindPopup("D103");
polygon2.bindPopup("A102");
polygon3.bindPopup("A103");
polygon4.bindPopup("A104");
polygon5.bindPopup("B101");
polygon6.bindPopup("E101");
polygon7.bindPopup("D101");        
polygon8.bindPopup("D104");
polygon9.bindPopup("C102");
polygon10.bindPopup("C103");
polygon11.bindPopup("C104"); 
polygon12.bindPopup("Extra1");
polygon13.bindPopup("Extra2");

//Add blue circle marker to two layer
//twoLayer.addLayer(blueCircleMarker);

//On click bring one layer to front
map.on('click', function(){
oneLayer.bringToFront();
});
//On dblclick bring two layer to front
map.on('dblclick', function(){
twoLayer.bringToFront();
});
        

var popup = L.popup();

function onMapClick(e) {

popup
.setLatLng(e.latlng)
.setContent("You clicked the map at " + e.latlng.toString())
.openOn(map);
}

map.on('click', onMapClick);


        
        
        

        
        
        


</script>

           
</body>

</html>