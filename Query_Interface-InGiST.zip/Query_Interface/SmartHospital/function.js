
var colors = [
'red', 'darkred', 'orange', 'green', 'darkgreen', 'blue', 'purple', 'darkpuple', 'cadetblue'
];
var colorIcons = [];

for (var i = 0; i < colors.length; i++) {
var colorIcon = L.AwesomeMarkers.icon({
markerColor: colors[i]
});
colorIcons.push(colorIcon);
}


    
//find all people   

var markers = [];
var totalTrackingObjects = 0;
var allpeople = function () {
markers = [];
 var pc = $("#track option:selected").val();
    var t1 = $('#t1').val();
var t2 = $('#t2').val();
 var pass = pc + ',' + t1 + ','+t2;
$.getJSON('http://172.17.137.160:3333/live/' +pass, function (data) {
    totalTrackingObjects = data.length;
    for (var i = 0; i < data.length; i++) {
         var cat = data[i].person_category;
        console.log(cat);
        if(cat == "PATIENT"){
            var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair', prefix: 'fa', markerColor: 'red'})}).addTo(map);
                markers.push(marker);
            //icn = 'wheelchair';
            }
        else if(cat == "DOCTOR")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'user-md', prefix: 'fa', markerColor: 'green'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "NURSE")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'medkit', prefix: 'fa', markerColor: 'blue'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }


        
        else{

                        var colorIcon = colorIcons[i % colors.length];
                        console.log(i % colors.length);
                       var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
                markers.push(marker);
        }


    }
});
updateallpeople();
};
//
var updateallpeople = function () {
 var pc = $("#track option:selected").val();
    var t1 = $('#t1').val();
var t2 = $('#t2').val();
 var pass = pc + ',' + t1 + ','+t2;
$.getJSON('http://172.17.137.160:3333/live/' +pass, function (data) {
    //totalTrackingObjects = data.length;
    if (data.length == 0) {
        alert("No Person Available\n\n                                          ****Do Not Check****\n'Prevent this page from creating additional dialogues'\n");
        window.location.reload();
        console.log("Detected 0");
        for (var i = 0; i < totalTrackingObjects; i++) {
            map.removeLayer(markers[i]);

            //window.location.reload();
        }
    } else if (data.length != totalTrackingObjects) {
        for (var i = 0; i < totalTrackingObjects; i++) {
            map.removeLayer(markers[i]);
        }
        allpeople();
    }
    for (var i = 0; i < data.length; i++) {
        var x = data[i].x;
        var y = data[i].y;
        var mac = data[i].mac;
        var cat = data[i].person_category;
        var room = data[i].room_name;
        markers[i].setLatLng([x, y]);
        markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat+'<br/>Room:'+room);
        //markers[i].openPopup();
    }
});
};

var findallpeopl = function () {
setTimeout(function () {
    updateallpeople();
    //clearTimeout(timeout);
    findallpeopl();

    //loadmap();
}, 1000);


};

var findallpeople = function () {
    allpeople();
    findallpeopl();
    
};


//find all assets


var markers = [];
var totalTrackingObjects = 0;
var allassets = function () {
markers = [];
 var pc = $("#track option:selected").val();
    var t1 = $('#t1').val();
var t2 = $('#t2').val();
 var pass = pc + ',' + t1 + ','+t2;
$.getJSON('http://172.17.137.160:3333/live/' +pass, function (data) {
    totalTrackingObjects = data.length;
    for (var i = 0; i < data.length; i++) {
         var cat = data[i].person_category;
        console.log(cat);
                if(cat == "WHEELCHAIR")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair-alt', prefix: 'fa', markerColor: 'green'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "STRECHER")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'bed', prefix: 'fa', markerColor: 'red'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "SURGICAL EQUIPEMENTS")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'scissors', prefix: 'fa', markerColor: 'orange'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                
        else{

                        var colorIcon = colorIcons[i % colors.length];
                        console.log(i % colors.length);
                       var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
                markers.push(marker);
        }


    }
});
updateallassets();
};
//
var updateallassets = function () {
 var pc = $("#track option:selected").val();
    var t1 = $('#t1').val();
var t2 = $('#t2').val();
 var pass = pc + ',' + t1 + ','+t2;
$.getJSON('http://172.17.137.160:3333/live/' +pass, function (data) {
    //totalTrackingObjects = data.length;
    if (data.length == 0) {
        alert("No Asset Available\n\n                                          ****Do Not Check****\n'Prevent this page from creating additional dialogues'\n");
        window.location.reload();
        console.log("Detected 0");
        for (var i = 0; i < totalTrackingObjects; i++) {
            map.removeLayer(markers[i]);

            //window.location.reload();
        }
    } else if (data.length != totalTrackingObjects) {
        for (var i = 0; i < totalTrackingObjects; i++) {
            map.removeLayer(markers[i]);
        }
        allassets();
    }
    for (var i = 0; i < data.length; i++) {
        var x = data[i].x;
        var y = data[i].y;
        var mac = data[i].mac;
        var cat = data[i].person_category;
        var room = data[i].room_name;
        markers[i].setLatLng([x, y]);
        markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat+'<br/>Room:'+room);
    }
});
};

var findallasset = function () {
setTimeout(function () {
    updateallassets();
    //clearTimeout(timeout);
    findallasset();

    //loadmap();
}, 1000);


};

var findallassets = function () {
    allassets();
    findallasset();
    
};



// find people based on the category
var markers = [];
var totalTrackingObjects = 0;
var onepc = function () {
markers = [];
 var pc = $("#category option:selected").val();
 var ma = $("#mac option:selected").val();
    var r = ma.split(',');
    var m = r[0];
    console.log(m);
 var t1 = $('#t1').val();
var t2 = $('#t2').val();
 var pass = m + ',' + pc + ',' + t1 + ','+t2;
$.getJSON('http://172.17.137.160:3333/findl/'+ pass, function (data) {
    totalTrackingObjects = data.length;
    for (var i = 0; i < data.length; i++) {
        var cat = data[i].person_category;
        console.log("cat1"+ cat);
        if(cat == "PATIENT"){
           var colorIcon = colorIcons[1];
            var marker1 = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair', prefix: 'fa', markerColor: 'red'})}).addTo(map);
            markers.push(marker1);
            //icn = 'wheelchair';
            }
        else if(cat == "DOCTOR")
                {
                var colorIcon = colorIcons[3];
                var marker2 = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'user-md', prefix: 'fa', markerColor: 'green'})}).addTo(map);
                markers.push(marker2);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                        else if(cat == "NURSE")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'medkit', prefix: 'fa', markerColor: 'blue'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
        else{

                        var colorIcon = colorIcons[i % colors.length];
                        console.log(i % colors.length);
                       var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
                markers.push(marker);
        }

    }
});
updateonepc();
};
//
var updateonepc = function () {

 var pc = $("#category option:selected").val();
 var ma = $("#mac option:selected").val();
    var r = ma.split(',');
    var m = r[0];
 var t1 = $('#t1').val();
var t2 = $('#t2').val();
 var pass = m + ',' + pc + ',' + t1 + ','+t2;
$.getJSON('http://172.17.137.160:3333/findl/'+ pass, function (data) {
    if (data.length == 0) {
        alert("No '" + pc +"' Available\n\n                                          ****Do Not Check****\n'Prevent this page from creating additional dialogues'\n");
        window.location.reload();
        console.log("Detected 0");
        for (var i = 0; i < totalTrackingObjects; i++) {
            map.removeLayer(markers[i]);

            //window.location.reload();
        }
    } else if (data.length != totalTrackingObjects) {
        for (var i = 0; i < totalTrackingObjects; i++) {
            map.removeLayer(markers[i]);
        }
         onepc();

    }

    for (var i = 0; i < data.length; i++) {
        var x = data[i].x;
        var y = data[i].y;
        var mac = data[i].mac;
        var cat = data[i].person_category;
        var room = data[i].room_name;
        markers[i].setLatLng([x, y]);
        markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat+'<br/>Room:'+room);
    }
});
};

var findonepc = function () {
setTimeout(function () {
    updateonepc();
    findonepc();

    //loadmap();
}, 1000);


}; 


// find assets based on the category
var markers = [];
var totalTrackingObjects = 0;
var onepca = function () {
markers = [];
 var pc = $("#category option:selected").val();
 var m = $("#mac option:selected").val();
 var t1 = $('#t1').val();
var t2 = $('#t2').val();
 var pass = m + ',' + pc + ',' + t1 + ','+t2;
$.getJSON('http://172.17.137.160:3333/finda/'+ pass, function (data) {
    totalTrackingObjects = data.length;
    for (var i = 0; i < data.length; i++) {
         var cat = data[i].person_category;
        console.log(cat);
                if(cat == "WHEELCHAIR")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair-alt', prefix: 'fa', markerColor: 'green'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "STRECHER")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'bed', prefix: 'fa', markerColor: 'red'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "SURGICAL EQUIPEMENTS")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'scissors', prefix: 'fa', markerColor: 'orange'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                
        else{

                        var colorIcon = colorIcons[i % colors.length];
                        console.log(i % colors.length);
                       var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
                markers.push(marker);
        }


    

    }
});
updateonepca();
};
//
var updateonepca = function () {

 var pc = $("#category option:selected").val();
 var m = $("#mac option:selected").val();
 var t1 = $('#t1').val();
var t2 = $('#t2').val();
 var pass = m + ',' + pc + ',' + t1 + ','+t2;
$.getJSON('http://172.17.137.160:3333/finda/'+ pass, function (data) {
    if (data.length == 0) {
        alert("No '" + pc +"' Available \n\n                                          ****Do Not Check****\n'Prevent this page from creating additional dialogues'\n");
        window.location.reload();
        console.log("Detected 0");
        for (var i = 0; i < totalTrackingObjects; i++) {
            map.removeLayer(markers[i]);

            //window.location.reload();
        }
    } else if (data.length != totalTrackingObjects) {
        for (var i = 0; i < totalTrackingObjects; i++) {
            map.removeLayer(markers[i]);
        }
         onepca();

    }

    for (var i = 0; i < data.length; i++) {
        var x = data[i].x;
        var y = data[i].y;
        var mac = data[i].mac;
        var cat = data[i].person_category;
        var room = data[i].room_name;
        markers[i].setLatLng([x, y]);
        markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat+'<br/>Room:'+room);
    }
});
};

var findonepca = function () {
setTimeout(function () {
    updateonepca();
    findonepca();

    //loadmap();
}, 1000);


}; 


//modal   
// find people in a room
var markers = [];
var totalTrackingObjects = 0;
var allinroom = function () {
    markers = [];
    var pc = $("#person_category2 option:selected").val(); 
     var r = $("#room1 option:selected").val();
     var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = pc + ',' + r + ',' + t1 + ','+t2;
    $.getJSON('http://172.17.137.160:3333/findr/'+ pass, function (data) {
        totalTrackingObjects = data.length;
    for (var i = 0; i < data.length; i++) {
        var cat = data[i].person_category;
        console.log("cat1"+ cat);
        if(cat == "PATIENT"){
           var colorIcon = colorIcons[1];
            var marker1 = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair', prefix: 'fa', markerColor: 'red'})}).addTo(map);
            markers.push(marker1);
            //icn = 'wheelchair';
            }
        else if(cat == "DOCTOR")
                {
                var colorIcon = colorIcons[3];
                var marker2 = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'user-md', prefix: 'fa', markerColor: 'green'})}).addTo(map);
                markers.push(marker2);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                        else if(cat == "NURSE")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'medkit', prefix: 'fa', markerColor: 'blue'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
        else{

                        var colorIcon = colorIcons[i % colors.length];
                        console.log(i % colors.length);
                       var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
                markers.push(marker);
        }

    }
    });
    updateallinroom();
};
//
var updateallinroom = function () {
        var pc = $("#person_category2 option:selected").val(); 
     var r = $("#room1 option:selected").val();
     var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = pc + ',' + r + ',' + t1 + ','+t2;
    $.getJSON('http://172.17.137.160:3333/findr/'+ pass, function (data) {
        if (data.length == 0) {
            alert("No '" + pc +", Available in the Room '" +r +"'\n\n                                          ****Do Not Check****\n'Prevent this page from creating additional dialogues'\n");
            window.location.reload();
            console.log("Detected 0");
            for (var i = 0; i < totalTrackingObjects; i++) {
                map.removeLayer(markers[i]);
            }
        } else if (data.length != totalTrackingObjects) {
            for (var i = 0; i < totalTrackingObjects; i++) {
                map.removeLayer(markers[i]);
            }
            allinroom();
        }
    for (var i = 0; i < data.length; i++) {
        var x = data[i].x;
        var y = data[i].y;
        var mac = data[i].mac;
        var cat = data[i].person_category;
        var room = data[i].room_name;
        markers[i].setLatLng([x, y]);
        markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat+'<br/>Room:'+room);
    }
    });
};

var findinroom = function () {
    setTimeout(function () {
        updateallinroom();
        findinroom();
        //loadmap();
    }, 1000);
};

var findroom = function () {
$('#peoplelive').modal('hide');
        $('#findallinroomb').removeClass('btn-success');
         $('#findallinroomb').addClass('hide');
        $('#stopallinroom').removeClass('hide');
        $('#stopallinroom').addClass('btn-success');
   document.getElementById("querya").disabled = true;
    document.getElementById("Track").disabled = true;
    $('#person_category2').attr('disabled',true);
    
   // document.getElementById('c1div').style.visibility = 'hidden';
  //  document.getElementById('c2div').style.visibility = 'hidden';
  //  document.getElementById('d1div').style.visibility = 'hidden';
  //  document.getElementById('d2div').style.visibility = 'hidden';
   //     document.getElementById('k1div').style.visibility = 'hidden';
  //  document.getElementById('k2div').style.visibility = 'hidden';
   // document.getElementById('findmdiv').style.visibility = 'hidden';
   // document.getElementById('findm1div').style.visibility = 'hidden';
   // document.getElementById('crowddiv').style.visibility = 'hidden';
    
        enableButton();
        findinroom();

};

 

//find k people        
var markers = [];
var totalTrackingObjects = 0;
var kpeople = function () {
    markers = [];
    markers1 =[];
     var ma = $("#mac6 option:selected").val();
        var r = ma.split(',');
    var m = r[0];
     var k = $("#k1 option:selected").val();
     var pc = $("#person_category9 option:selected").val();
        var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
    $.getJSON('http://172.17.137.160:3333/findk/'+ pass, function (data) {
        totalTrackingObjects = data.length;
        for (var i = 0; i < data.length; i++) {
         var cat = pc;
if(cat == "PATIENT"){
    var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair', prefix: 'fa', markerColor: 'red'})}).addTo(map);
      var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
    markers1.push(marker1);
        markers.push(marker);
    //icn = 'wheelchair';
    }
else if(cat == "DOCTOR")
        {
        var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'user-md', prefix: 'fa', markerColor: 'green'})}).addTo(map);
        var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
            markers1.push(marker1);
        markers.push(marker);
        //icn = 'user-md';
        //icon = 'medkit';
        }
        else if(cat == "NURSE")
        {
        var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'medkit', prefix: 'fa', markerColor: 'blue'})}).addTo(map);
          var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
            markers1.push(marker1);
        markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
        else{
            var colorIcon = colorIcons[i % colors.length];
            console.log(i % colors.length);
            var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
            var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
            markers.push(marker);
            markers1.push(marker1);
        }
        }
    });
    updatek();
};
//
var updatek = function () {

    var pc1 = $("#person_category10 option:selected").val();
    var ma = $("#mac6 option:selected").val();
        var r = ma.split(',');
    var m = r[0];
    var k = $("#k1 option:selected").val();
    var pc = $("#person_category9 option:selected").val();
    var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
    $.getJSON('http://172.17.137.160:3333/findk/'+ pass, function (data) {
        if (data.length == 0) {
            alert("No Nearest '" + pc +"' Available for the  '" + pc1 +"''" +m +"'\n\n                                          ****Do Not Check****\n'Prevent this page from creating additional dialogues'\n");
            window.location.reload();
            console.log("Detected 0");
            for (var i = 0; i < totalTrackingObjects; i++) {
                map.removeLayer(markers[i]);
                   map.removeLayer(markers1[i]);
            }
        } else if (data.length != totalTrackingObjects) {
            for (var i = 0; i < totalTrackingObjects; i++) {
                map.removeLayer(markers[i]);
                map.removeLayer(markers1[i]);
            }
            kpeople();
        }
    for (var i = 0; i < data.length; i++) {
            var x = data[i].x;
            var y = data[i].y;
            var x1 = data[i].x1;
            var y1 = data[i].y1;
            var mac = data[i].mac;
            var mac1 = data[i].mac1;
            //var cat = pc;
            var cat = data[i].person_category;
            var cat1 = pc1;
            var room = data[i].room_name;
            markers[i].setLatLng([x, y]);
            markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat+'<br/>Room:'+room);
           markers1[i].setLatLng([x1, y1]);
            markers1[i].bindPopup('x:'+x1+'<br/>y:'+y1+'<br/>NAME:'+mac1+'<br/>Category:'+cat1);
        
    }
    });
};

var findkp = function () {
    setTimeout(function () {
        updatek();
        findkp();
        //loadmap();
    }, 1000);
}; 
var findk = function () {
$('#peoplelive').modal('hide');
            $('#findkb').removeClass('btn-success');
         $('#findkb').addClass('hide');
        $('#findkbs').removeClass('hide');
        $('#findkbs').addClass('btn-success');
     document.getElementById("querya").disabled = true;
     document.getElementById("Track").disabled = true;
    $('#person_category9').attr('disabled',true);
        $('#person_category10').attr('disabled',true);
        $('#mac6').attr('disabled',true);
     //$('#k1').attr('disabled',true);

        /*document.getElementById('c1div').style.visibility = 'hidden';
    document.getElementById('c2div').style.visibility = 'hidden';
    document.getElementById('d1div').style.visibility = 'hidden';
    document.getElementById('d2div').style.visibility = 'hidden';
        document.getElementById('roomdiv').style.visibility = 'hidden';
    document.getElementById('k2div').style.visibility = 'hidden';
    document.getElementById('findmdiv').style.visibility = 'hidden';
    document.getElementById('findm1div').style.visibility = 'hidden';
    document.getElementById('crowddiv').style.visibility = 'hidden';*/
        enableButton();
        findkp();

};




//find k people from a location       
var markers = [];
var totalTrackingObjects = 0;
var kpeople1 = function () {
    markers = [];

     var m = $("#room4 option:selected").val();
     var k = $("#k2 option:selected").val();
     var pc = $("#person_category11 option:selected").val();
     var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
    $.getJSON('http://172.17.137.160:3333/findk1/'+ pass, function (data) {
        totalTrackingObjects = data.length;
         for (var i = 0; i < data.length; i++) {
         var cat = pc;
if(cat == "PATIENT"){
    var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair', prefix: 'fa', markerColor: 'red'})}).addTo(map);
        markers.push(marker);
    //icn = 'wheelchair';
    }
else if(cat == "DOCTOR")
        {
        var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'user-md', prefix: 'fa', markerColor: 'green'})}).addTo(map);
        markers.push(marker);
        //icn = 'user-md';
        //icon = 'medkit';
        }
        else if(cat == "NURSE")
        {
        var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'medkit', prefix: 'fa', markerColor: 'blue'})}).addTo(map);
        markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
        else{
            var colorIcon = colorIcons[i % colors.length];
            console.log(i % colors.length);
            var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
            markers.push(marker);
        }
        }
    });
    updatek1();
};
//
var updatek1 = function () {
     var m = $("#room4 option:selected").val();
     var k = $("#k2 option:selected").val();
     var pc = $("#person_category11 option:selected").val();
     var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
     $.getJSON('http://172.17.137.160:3333/findk1/'+ pass, function (data) {
        if (data.length == 0) {
            alert("No Nearest '" + pc +"' Available for the Room '" + m +"'\n\n                                          ****Do Not Check****\n'Prevent this page from creating additional dialogues'\n");
            window.location.reload();
            console.log("Detected 0");
            for (var i = 0; i < totalTrackingObjects; i++) {
                map.removeLayer(markers[i]);
            }
        } else if (data.length != totalTrackingObjects) {
            for (var i = 0; i < totalTrackingObjects; i++) {
                map.removeLayer(markers[i]);
            }
            kpeople1();
        }
        for (var i = 0; i < data.length; i++) {
        var x = data[i].x;
        var y = data[i].y;
        var mac = data[i].mac;
        var cat = pc;
        var room = data[i].room_name;
        markers[i].setLatLng([x, y]);
        markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat+'<br/>Room:'+room);
        
        }
    });
};

var findkp1 = function () {
    setTimeout(function () {
        updatek1();
        findkp1();
        //loadmap();
    }, 1000);
};

var findk1 = function () {
$('#peoplelive').modal('hide');
                $('#findk1b').removeClass('btn-success');
         $('#findk1b').addClass('hide');
        $('#findk1bs').removeClass('hide');
        $('#findk1bs').addClass('btn-success');
    document.getElementById("querya").disabled = true;
     document.getElementById("Track").disabled = true;
        $('#person_category11').attr('disabled',true);
        $('#room4').attr('disabled',true);
    
        enableButton();
        findkp1();

};

        
//find people within n meters of a person        
var markers = [];
var totalTrackingObjects = 0;
var mpeople = function () {
    markers = [];
    markers1 =[];
     var ma = $("#mac5 option:selected").val();
        var r = ma.split(',');
    var m = r[0];
     var k = $("#meters1 option:selected").val();
     var pc = $("#person_category6 option:selected").val();
     var pc1 = $("#person_category8 option:selected").val();
     var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
     $.getJSON('http://172.17.137.160:3333/findm/'+ pass, function (data) {
        totalTrackingObjects = data.length;
        for (var i = 0; i < data.length; i++) {
         var cat = pc;
if(cat == "PATIENT"){
    var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair', prefix: 'fa', markerColor: 'red'})}).addTo(map);
      var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
    markers1.push(marker1);
        markers.push(marker);
    //icn = 'wheelchair';
    }
else if(cat == "DOCTOR")
        {
        var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'user-md', prefix: 'fa', markerColor: 'green'})}).addTo(map);
        var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
            markers1.push(marker1);
        markers.push(marker);
        //icn = 'user-md';
        //icon = 'medkit';
        }
        else if(cat == "NURSE")
        {
        var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'medkit', prefix: 'fa', markerColor: 'blue'})}).addTo(map);
          var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
            markers1.push(marker1);
        markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
        else{
            var colorIcon = colorIcons[i % colors.length];
            console.log(i % colors.length);
            var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
            var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
            markers.push(marker);
            markers1.push(marker1);
        }
        }
    });
    updatem();
};
//
var updatem = function () {
     var ma = $("#mac5 option:selected").val();
        var r = ma.split(',');
    var m = r[0];
     var k = $("#meters1 option:selected").val();
     var pc = $("#person_category6 option:selected").val();
     var pc1 = $("#person_category8 option:selected").val();
     var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
     $.getJSON('http://172.17.137.160:3333/findm/'+ pass, function (data) {
        if (data.length == 0) {
            alert("No '" + pc +"' Available within  '" + k +"' Meters of '" +pc1 +"' '" +m +"'\n\n                                          ****Do Not Check****\n'Prevent this page from creating additional dialogues'\n");
            window.location.reload();
            console.log("Detected 0");
            for (var i = 0; i < totalTrackingObjects; i++) {
                map.removeLayer(markers[i]);
                map.removeLayer(markers1[i]);
            }
        } else if (data.length != totalTrackingObjects) {
            for (var i = 0; i < totalTrackingObjects; i++) {
                map.removeLayer(markers[i]);
                map.removeLayer(markers1[i]);
            }
            mpeople();
        }
        for (var i = 0; i < data.length; i++) {
            var x = data[i].x;
            var y = data[i].y;
            var x1 = data[i].x1;
            var y1 = data[i].y1;
            var mac = data[i].mac;
            var mac1 = data[i].mac1;
            var cat = pc;
            var cat1 = pc1;
                    var room = data[i].room_name;
                markers[i].setLatLng([x, y]);
            markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat+'<br/>Room:'+room);
            markers1[i].setLatLng([x1,y1]);
            markers1[i].bindPopup('x:'+x1+'<br/>y:'+y1+'<br/>NAME:'+mac1+'<br/>Category:'+cat1);
        
        }
    });
};

var findmp = function () {
    setTimeout(function () {
        updatem();
        findmp();
        //loadmap();
    }, 1000);
};  
var findm = function () {
$('#peoplelive').modal('hide');
                $('#findm2b').removeClass('btn-success');
         $('#findm2b').addClass('hide');
        $('#findm2bs').removeClass('hide');
        $('#findm2bs').addClass('btn-success');
  document.getElementById("querya").disabled = true;
     document.getElementById("Track").disabled = true;
            $('#person_category6').attr('disabled',true);
         $('#person_category8').attr('disabled',true);
    // $('#meters1').attr('disabled',true);
          $('#mac5').attr('disabled',true);
    
      /*     document.getElementById('c1div').style.visibility = 'hidden';
    document.getElementById('c2div').style.visibility = 'hidden';
    document.getElementById('d1div').style.visibility = 'hidden';
    document.getElementById('d2div').style.visibility = 'hidden';
        document.getElementById('k1div').style.visibility = 'hidden';
    document.getElementById('k2div').style.visibility = 'hidden';
    document.getElementById('roomdiv').style.visibility = 'hidden';
    document.getElementById('findm1div').style.visibility = 'hidden';
    document.getElementById('crowddiv').style.visibility = 'hidden';*/
        enableButton();
        findmp();

};


//find people within n meters of a location       
var markers = [];
var totalTrackingObjects = 0;
var mpeople1 = function () {
    markers = [];
     var m = $("#room3 option:selected").val();
     var k = $("#meters2 option:selected").val();
     var pc = $("#person_category7 option:selected").val();
     var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
    
    $.getJSON('http://172.17.137.160:3333/findm1/'+ pass, function (data) {
        totalTrackingObjects = data.length;
        for (var i = 0; i < data.length; i++) {
         var cat = pc;
if(cat == "PATIENT"){
    var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair', prefix: 'fa', markerColor: 'red'})}).addTo(map);
        markers.push(marker);
    //icn = 'wheelchair';
    }
else if(cat == "DOCTOR")
        {
        var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'user-md', prefix: 'fa', markerColor: 'green'})}).addTo(map);
        markers.push(marker);
        //icn = 'user-md';
        //icon = 'medkit';
        }
        else if(cat == "NURSE")
        {
        var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'medkit', prefix: 'fa', markerColor: 'blue'})}).addTo(map);
        markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
        else{
            var colorIcon = colorIcons[i % colors.length];
            console.log(i % colors.length);
            var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
            markers.push(marker);
        }
        }
    });
    updatem1();
};
//
var updatem1 = function () {
     var m = $("#room3 option:selected").val();
     var k = $("#meters2 option:selected").val();
     var pc = $("#person_category7 option:selected").val();
     var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
     $.getJSON('http://172.17.137.160:3333/findm1/'+ pass, function (data) {
        if (data.length == 0) {
            alert("No '" + pc +"' Available within  '" + k +"' Meters of Room'" +m +"'\n\n                                          ****Do Not Check****\n'Prevent this page from creating additional dialogues'\n");
            window.location.reload();
            console.log("Detected 0");
            for (var i = 0; i < totalTrackingObjects; i++) {
                map.removeLayer(markers[i]);
            }
        } else if (data.length != totalTrackingObjects) {
            for (var i = 0; i < totalTrackingObjects; i++) {
                map.removeLayer(markers[i]);
            }
            mpeople1();
        }
        for (var i = 0; i < data.length; i++) {
        var x = data[i].x;
        var y = data[i].y;
        var mac = data[i].mac;
        var cat = pc;
        var room = data[i].room_name;
        markers[i].setLatLng([x, y]);
        markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat+'<br/>Room:'+room);
        }
    });
};

var findm1p = function () {
    setTimeout(function () {
        updatem1();
        findm1p();
        //loadmap();
    }, 1000);
}; 
var findm1 = function () {
$('#peoplelive').modal('hide');
                $('#findm1b').removeClass('btn-success');
         $('#findm1b').addClass('hide');
        $('#findm1bs').removeClass('hide');
        $('#findm1bs').addClass('btn-success');
    document.getElementById("querya").disabled = true;
    document.getElementById("Track").disabled = true;
             $('#person_category7').attr('disabled',true);
     //$('#meters2').attr('disabled',true);
         // $('#room3').attr('disabled',true);
        enableButton();
        findm1p();

};


//asset

 var markers = [];
        var totalTrackingObjects = 0;
        var allinrooma = function () {
            markers = [];
                var pc = $("#asset_category2 option:selected").val(); 
     var r = $("#roomA1 option:selected").val();
     var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = pc + ',' + r + ',' + t1 + ','+t2;
            $.getJSON('http://172.17.137.160:3333/findra/'+ pass, function (data) {
                totalTrackingObjects = data.length;
        for (var i = 0; i < data.length; i++) {
         var cat = pc;
        console.log(cat);
                if(cat == "WHEELCHAIR")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair-alt', prefix: 'fa', markerColor: 'green'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "STRECHER")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'bed', prefix: 'fa', markerColor: 'red'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "SURGICAL EQUIPEMENTS")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'scissors', prefix: 'fa', markerColor: 'orange'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                
        else{

                        var colorIcon = colorIcons[i % colors.length];
                        console.log(i % colors.length);
                       var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
                markers.push(marker);
        }


    }
            });
            updateallinrooma();
        };
        //
        var updateallinrooma = function () {
                var pc = $("#asset_category2 option:selected").val(); 
     var r = $("#roomA1 option:selected").val();
     var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = pc + ',' + r + ',' + t1 + ','+t2;
            $.getJSON('http://172.17.137.160:3333/findra/'+ pass, function (data) {
                if (data.length == 0) {
                    alert("No Asset Available in the Room '" +r +"'\n\n                                          ****Do Not Check****\n'Prevent this page from creating additional dialogues'\n");
                    window.location.reload();
                    console.log("Detected 0");
                    for (var i = 0; i < totalTrackingObjects; i++) {
                        map.removeLayer(markers[i]);
                    }
                } else if (data.length != totalTrackingObjects) {
                    for (var i = 0; i < totalTrackingObjects; i++) {
                        map.removeLayer(markers[i]);
                    }
                    allinrooma();
                }
                for (var i = 0; i < data.length; i++) {
                    var x = data[i].x;
                    var y = data[i].y;
                    var cat = data[i].asset_category;
                    var mac = data[i].mac;
                    var room = data[i].room_name;
                    markers[i].setLatLng([x, y]);
                    markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat+'<br/>Room:'+room);
                }
            });
        };

        var findinraa = function () {
            setTimeout(function () {
                updateallinrooma();
                findinraa();
                //loadmap();
            }, 1000);
        };
var findinra = function () {
$('#assetlive').modal('hide');

    
    
    
            $('#findallinroomba').removeClass('btn-success');
         $('#findallinroomba').addClass('hide');
        $('#stopallinrooma').removeClass('hide');
        $('#stopallinrooma').addClass('btn-success');
   document.getElementById("queryp").disabled = true;
    document.getElementById("Track").disabled = true;
    $('#asset_category2').attr('disabled',true);
   // document.getElementById('c1div').style.visibility = 'hidden';
  //  document.getElementById('c2div').style.visibility = 'hidden';
  //  document.getElementById('d1div').style.visibility = 'hidden';
  //  document.getElementById('d2div').style.visibility = 'hidden';
   //     document.getElementById('k1div').style.visibility = 'hidden';
  //  document.getElementById('k2div').style.visibility = 'hidden';
   // document.getElementById('findmdiv').style.visibility = 'hidden';
   // document.getElementById('findm1div').style.visibility = 'hidden';
   // document.getElementById('crowddiv').style.visibility = 'hidden';
    
        enableButton();
     findinraa();

};


//find k asset       
                 var markers = [];
        var totalTrackingObjects = 0;
        var kpeoplea = function () {
            markers = [];
            markers1 =[];
             var m = $("#epc6 option:selected").val();
             var k = $("#ka1 option:selected").val();
              var pc = $("#asset_category9 option:selected").val();
             var pc1 = $("#asset_category10 option:selected").val();
                 var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
    $.getJSON('http://172.17.137.160:3333/findka/'+ pass, function (data) {
        totalTrackingObjects = data.length;
        for (var i = 0; i < data.length; i++) {
                 var cat = pc;
        console.log(cat);
                if(cat == "WHEELCHAIR")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair-alt', prefix: 'fa', markerColor: 'green'})}).addTo(map);
                markers.push(marker);
                              var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
            markers1.push(marker1);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "STRECHER")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'bed', prefix: 'fa', markerColor: 'red'})}).addTo(map);
                markers.push(marker);
                              var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
            markers1.push(marker1);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "SURGICAL EQUIPEMENTS")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'scissors', prefix: 'fa', markerColor: 'orange'})}).addTo(map);
                markers.push(marker);
                              var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
            markers1.push(marker1);
                //icn = 'user-md';
                //icon = 'medkit';
                }
        else{
            var colorIcon = colorIcons[i % colors.length];
            console.log(i % colors.length);
            var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
            var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
            markers.push(marker);
            markers1.push(marker1);
        }
        }
                
                
                
                
                
            });
            updateka();
        };
        //
        var updateka = function () {
             var m = $("#epc6 option:selected").val();
             var k = $("#ka1 option:selected").val();
              var pc = $("#asset_category9 option:selected").val();
            var pc1 = $("#asset_category10 option:selected").val();
                 var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
    $.getJSON('http://172.17.137.160:3333/findka/'+ pass, function (data) {
                if (data.length == 0) {
                    alert("No Nearest Asset Available for the '" +m +"' \n\n                                          ****Do Not Check****\n'Prevent this page from creating additional dialogues'\n");
            window.location.reload();
                    console.log("Detected 0");
                    for (var i = 0; i < totalTrackingObjects; i++) {
                        map.removeLayer(markers[i]);
                        map.removeLayer(markers1[i]);
                    }
                } else if (data.length != totalTrackingObjects) {
                    for (var i = 0; i < totalTrackingObjects; i++) {
                        map.removeLayer(markers[i]);
                        map.removeLayer(markers1[i]);
                    }
                    kpeoplea();
                }
                for (var i = 0; i < data.length; i++) {
                    var x = data[i].x;
                    var y = data[i].y;
                    var x1 = data[i].x1;
                    var y1 = data[i].y1;
                    var mac = data[i].mac;
                    var mac1 = data[i].mac1;
                    var cat = pc;
                    var cat1 = pc1;
                            var room = data[i].room_name;
        markers[i].setLatLng([x, y]);
        markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat+'<br/>Room:'+room);

                    markers1[i].setLatLng([x1,y1]);
                    markers1[i].bindPopup('<bPeopler/>x:'+x1+'<br/>y:'+y1+'<br/>Category:'+cat1);
                }
            });
        };

        var findkaa = function () {
            setTimeout(function () {
                updateka();
                findkaa();
                //loadmap();
            }, 1000);
        };  
        var findka = function () {
$('#assetlive').modal('hide');
                                $('#findkba').removeClass('btn-success');
         $('#findkba').addClass('hide');
        $('#findkbsa').removeClass('hide');
        $('#findkbsa').addClass('btn-success');
  document.getElementById("queryp").disabled = true;
     document.getElementById("Track").disabled = true;
            $('#asset_category9').attr('disabled',true);
            $('#asset_category10').attr('disabled',true);
         $('#epc6').attr('disabled',true);
             enableButton();
        findkaa();

};
         
        
//find k asset from a location       
                 var markers = [];
        var totalTrackingObjects = 0;
        var kpeoplea1 = function () {
            markers = [];
       
             var m = $("#roomA4 option:selected").val();
             var k = $("#ka2 option:selected").val();
        
                var pc = $("#asset_category11 option:selected").val();
                 var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
    $.getJSON('http://172.17.137.160:3333/findk1a/'+ pass, function (data) {
        totalTrackingObjects = data.length;
        for (var i = 0; i < data.length; i++) {
 var cat = pc;
        console.log(cat);
                if(cat == "WHEELCHAIR")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair-alt', prefix: 'fa', markerColor: 'green'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "STRECHER")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'bed', prefix: 'fa', markerColor: 'red'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "SURGICAL EQUIPEMENTS")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'scissors', prefix: 'fa', markerColor: 'orange'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                
        else{

                        var colorIcon = colorIcons[i % colors.length];
                        console.log(i % colors.length);
                       var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
                markers.push(marker);
        }
        }
            });
            updateka1();
        };
        //
        var updateka1 = function () {
             var m = $("#roomA4 option:selected").val();
             var k = $("#ka2 option:selected").val();
        
                var pc = $("#asset_category11 option:selected").val();
                 var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
    $.getJSON('http://172.17.137.160:3333/findk1a/'+ pass, function (data) {
                if (data.length == 0) {
                                alert("No Nearest Asset Available for the Room '" + m +"'\n\n                                          ****Do Not Check****\n'Prevent this page from creating additional dialogues'\n");
            window.location.reload();
                    console.log("Detected 0");
                    for (var i = 0; i < totalTrackingObjects; i++) {
                        map.removeLayer(markers[i]);
                    }
                } else if (data.length != totalTrackingObjects) {
                    for (var i = 0; i < totalTrackingObjects; i++) {
                        map.removeLayer(markers[i]);
                    }
                    kpeoplea1();
                }
                for (var i = 0; i < data.length; i++) {
                    var x = data[i].x;
                    var y = data[i].y;
                    var cat = pc;
                    var room = data[i].room_name;
                    var mac = data[i].mac;
                    markers[i].setLatLng([x, y]);
                    markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat+'<br/>Room:'+room);
                }
            });
        };

        var findkaa1 = function () {
            setTimeout(function () {
                updateka1();
                findkaa1();
                //loadmap();
            }, 1000);
        };  
        var findka1 = function () {
$('#assetlive').modal('hide');
                                $('#findk1ba').removeClass('btn-success');
         $('#findk1ba').addClass('hide');
        $('#findk1bsa').removeClass('hide');
        $('#findk1bsa').addClass('btn-success');
  document.getElementById("queryp").disabled = true;
     document.getElementById("Track").disabled = true;
            $('#asset_category11').attr('disabled',true);
         $('#roomA4').attr('disabled',true);
        enableButton();

        findkaa1();

};
        
//find asset within n meters of an asset       
                 var markers = [];
        var totalTrackingObjects = 0;
        var mpeoplea = function () {
            markers = [];
            markers1 =[];
             var m = $("#epc5 option:selected").val();
             var k = $("#metersa1 option:selected").val();
            var pc = $("#asset_category7 option:selected").val();
                 var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
            $.getJSON('http://172.17.137.160:3333/findma/'+ pass, function (data) {
                totalTrackingObjects = data.length;
        for (var i = 0; i < data.length; i++) {
         var cat = pc;
        console.log(cat);
                if(cat == "WHEELCHAIR")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair-alt', prefix: 'fa', markerColor: 'green'})}).addTo(map);
                markers.push(marker);
                              var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
            markers1.push(marker1);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "STRECHER")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'bed', prefix: 'fa', markerColor: 'red'})}).addTo(map);
                markers.push(marker);
                              var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
            markers1.push(marker1);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "SURGICAL EQUIPEMENTS")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'scissors', prefix: 'fa', markerColor: 'orange'})}).addTo(map);
                markers.push(marker);
                              var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
            markers1.push(marker1);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                
        else{

                        var colorIcon = colorIcons[i % colors.length];
                        console.log(i % colors.length);
                       var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
                markers.push(marker);
                      var marker1 = L.marker([0,0], {icon: L.AwesomeMarkers.icon({icon: 'user-o', prefix: 'fa', markerColor: 'black' , spin:false}) }).addTo(map);
            markers1.push(marker1);
        }


    }
            });
            updatema();
        };
        //
        var updatema = function () {
             var m = $("#epc5 option:selected").val();
             var k = $("#metersa1 option:selected").val();
            var pc = $("#asset_category7 option:selected").val();
                 var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
            $.getJSON('http://172.17.137.160:3333/findma/'+ pass, function (data) {
                if (data.length == 0) {
                    alert("No Assets Available within  '" + k +"' Meters of '" +m +"'\n\n                                          ****Do Not Check****\n'Prevent this page from creating additional dialogues'\n");
              window.location.reload();
                    console.log("Detected 0");
                    for (var i = 0; i < totalTrackingObjects; i++) {
                        map.removeLayer(markers[i]);
                        map.removeLayer(markers1[i]);
                    }
                } else if (data.length != totalTrackingObjects) {
                    for (var i = 0; i < totalTrackingObjects; i++) {
                        map.removeLayer(markers[i]);
                        map.removeLayer(markers1[i]);
                    }
                    mpeoplea();
                }
                for (var i = 0; i < data.length; i++) {
                    var x = data[i].x;
                    var y = data[i].y;
                    var x1 = data[i].x1;
                    var y1 = data[i].y1;
                    var mac = data[i].mac;
                    var mac1 = data[i].mac1;
                    var room = data[i].room_name;
                    var cat = pc;
                    markers[i].setLatLng([x, y]);
                    markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat+'<br/>Room:'+room);
                  //  markers1[i].setLatLng([x1,y1]);
                    //markers1[i].bindPopup('<br/>x:'+x1+'<br/>y:'+y1);
                     markers1[i].setLatLng([x1,y1]);
                    markers1[i].bindPopup('x:'+x1+'<br/>y:'+y1+'<br/>NAME:'+mac1);
                }
            });
        };

        var findmaa = function () {
            setTimeout(function () {
                updatema();
                findmaa();
                //loadmap();
            }, 1000);
        }; 
var findma = function () {
$('#assetlive').modal('hide');
          
                    $('#findm2ba').removeClass('btn-success');
         $('#findm2ba').addClass('hide');
        $('#findm2bsa').removeClass('hide');
        $('#findm2bsa').addClass('btn-success');
  document.getElementById("queryp").disabled = true;
     document.getElementById("Track").disabled = true;
            $('#asset_category7').attr('disabled',true);
         $('#asset_category8').attr('disabled',true);
    // $('#meters1a').attr('disabled',true);
          $('#epc5').attr('disabled',true);
        enableButton();
        findmaa();

};







        
//find asset within n meters of a location       
        var markers = [];
        var totalTrackingObjects = 0;
        var mpeoplea1 = function () {
            markers = [];
            markers1 =[];
             var m = $("#roomA3 option:selected").val();
             var k = $("#metersa2 option:selected").val();
            var pc = $("#asset_category6 option:selected").val();
                 var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
            $.getJSON('http://172.17.137.160:3333/findm1a/'+ pass, function (data) {
                totalTrackingObjects = data.length;
                for (var i = 0; i < data.length; i++) {
         var cat = pc;
        console.log(cat);
                if(cat == "WHEELCHAIR")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'wheelchair-alt', prefix: 'fa', markerColor: 'green'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "STRECHER")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'bed', prefix: 'fa', markerColor: 'red'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                else if(cat == "SURGICAL EQUIPEMENTS")
                {
                var marker = L.marker([0,0], { icon: L.AwesomeMarkers.icon({icon: 'scissors', prefix: 'fa', markerColor: 'orange'})}).addTo(map);
                markers.push(marker);
                //icn = 'user-md';
                //icon = 'medkit';
                }
                
        else{

                        var colorIcon = colorIcons[i % colors.length];
                        console.log(i % colors.length);
                       var marker = L.marker([0,0], { icon: colorIcon }).addTo(map);
                markers.push(marker);
        }
                }
            });
            updatema1();
        };
        //
        var updatema1 = function () {
             var m = $("#roomA3 option:selected").val();
             var k = $("#metersa2 option:selected").val();
            var pc = $("#asset_category6 option:selected").val();
                 var t1 = $('#t1').val();
    var t2 = $('#t2').val();
    var pass = m + ',' + k + ',' + pc + ',' + t1 + ','+t2;
            $.getJSON('http://172.17.137.160:3333/findm1a/'+ pass, function (data) {
                if (data.length == 0) {
                alert("No Assets Available within  '" + k +"' Meters of Room'" +m +"'\n\n                                          ****Do Not Check****\n'Prevent this page from creating additional dialogues'\n");
                    //window.prompt("No Assets Available within  '" + k +"' Meters of Room'" +m +"'");
            window.location.reload();
                    console.log("Detected 0");
                    for (var i = 0; i < totalTrackingObjects; i++) {
                        map.removeLayer(markers[i]);
                    }
                } else if (data.length != totalTrackingObjects) {
                    for (var i = 0; i < totalTrackingObjects; i++) {
                        map.removeLayer(markers[i]);
                    }
                    mpeoplea1();
                }
                for (var i = 0; i < data.length; i++) {
                    var x = data[i].x;
                    var y = data[i].y;
                    var mac = data[i].mac;
                    var cat = pc;
        var room = data[i].room_name;
        markers[i].setLatLng([x, y]);
        markers[i].bindPopup('x:'+x+'<br/>y:'+y+'<br/>NAME:'+mac+'<br/>Category:'+cat+'<br/>Room:'+room);
                }
            });
        };

        var findmaa1 = function () {
            setTimeout(function () {
                updatema1();
                findmaa1();
                //loadmap();
            }, 1000);
        }; 
var findma1 = function () {
$('#assetlive').modal('hide');
          
                    $('#findm1ba').removeClass('btn-success');
         $('#findm1ba').addClass('hide');
        $('#findm1bsa').removeClass('hide');
        $('#findm1bsa').addClass('btn-success');
  document.getElementById("queryp").disabled = true;
     document.getElementById("Track").disabled = true;
         $('#asset_category6').attr('disabled',true);
     $('#roomA3').attr('disabled',true);
        enableButton();
        findmaa1();

};
        
