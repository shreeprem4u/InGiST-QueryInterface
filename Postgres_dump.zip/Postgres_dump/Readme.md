##install postgres and postgis

https://gist.github.com/mdiener21/4ea94d50f1260bee39647d99517f6e9d

## Install dump

pip install dump 

## create a databasae

## create postgis extension
method 1. execute the query "CREATE EXTENSION postgis;"
method 2. run the file postgisext.py
python postgisext.py

## Backup

to backup the tables

    dump backup --dbname=... --username=...  --password=... --dir /some/base/path table1 table2 ...
    
example : python __main__.py  backup --dbname=Output --username=system  --password=system --host=172.17.9.60 --dir /home/researcher/Documents/ chair

## Restore

to restore the entire backup directory:

    dump restore --dbname=... --username=...  --password=... --dir /some/base/path

example : python __main__.py  restore --dbname=smartbuilding --username=amudalab3  --password=amudalab --host=172.17.137.160 --dir /home/researcher/Documents/


