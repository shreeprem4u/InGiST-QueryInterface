import sys

import dump

sys.exit(dump.console())

