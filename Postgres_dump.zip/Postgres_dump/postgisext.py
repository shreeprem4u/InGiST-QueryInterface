import psycopg2

def postgisext():
	try:
		conn = psycopg2.connect("dbname='smartbuilding' port='5432' user='amudalab3' host='172.17.137.160' password='amudalab'")
		cur = conn.cursor()		
		cur.execute("CREATE EXTENSION postgis")
		conn.commit()
		cur.close()
	except:
		print("Connection Error")


postgisext()
